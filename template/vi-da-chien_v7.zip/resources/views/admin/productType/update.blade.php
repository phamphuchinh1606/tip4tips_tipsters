@extends('admin.layouts.master')

@section('head.css')@endsection

@section('body.js')@endsection

@section('body.content')
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Cập Nhật Danh Mục</strong>
                                    <div class="card-header-actions">
                                        <a class="btn btn-sm btn-secondary" href="{{route('admin.product_type.index')}}">
                                            Quay Lại
                                        </a>
                                    </div>
                                </div>
                                <form class="form-horizontal" action="{{route('admin.product_type.update',['id' => $productType->id])}}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Tên Danh Mục </label>
                                            <div class="col-md-10">
                                                <input class="form-control" id="text-input" type="text" name="product_type_name" required
                                                    value="{{$productType->product_type_name}}">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-lable" for="">Công Khai</label>
                                            <div class="col-md-10">
                                                <label class="switch switch-label switch-outline-primary-alt">
                                                    <input class="switch-input" type="checkbox" {{$productType->is_check_public}} name="is_public">
                                                    <span class="switch-slider" data-checked="On" data-unchecked="Off"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-sm btn-primary" type="submit">
                                            <i class="fa fa-dot-circle-o"></i>Cập Nhật</button>
                                        <button class="btn btn-sm btn-danger" type="reset">
                                            <i class="fa fa-ban"></i>&nbspHủy&nbsp</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <form class="form-horizontal" action="{{route('admin.product_type.create_children',['id' => $productType->id])}}" method="post" enctype="multipart/form-data">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Tạo Danh Mục Con</strong>
                                        <div class="card-header-actions">
                                            <button class="btn btn-sm btn-primary" type="submit">
                                                Thêm
                                            </button>
                                        </div>
                                    </div>
                                    @csrf
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Tên Danh Mục </label>
                                            <div class="col-md-10">
                                                <input class="form-control" id="text-input" type="text" name="product_type_name" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-lable" for="">Công Khai</label>
                                            <div class="col-md-10">
                                                <label class="switch switch-label switch-outline-primary-alt">
                                                    <input class="switch-input" type="checkbox" checked name="is_public">
                                                    <span class="switch-slider" data-checked="On" data-unchecked="Off"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-header">
                                        <strong>Danh Sách Danh Mục Con</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-responsive-sm table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Tên Danh Mục</th>
                                                <th>Tình Trạng</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($listChildren as $productTypeChild)
                                                    <tr>
                                                        <td>{{$productTypeChild->product_type_name}}</td>
                                                        <td>
                                                            <span class="badge {{$productTypeChild->public_class}}">{{$productTypeChild->public_name}}</span>
                                                        </td>
                                                        <td>
                                                            <a data-toggle="modal" class="btn btn-danger anchorClick"
                                                                data-url="{{route('admin.product_type.delete_children',['id' => $productType->id, 'childId' => $productTypeChild->id])}}"
                                                                data-name="{{$productTypeChild->product_type_name}}" href="#deleteModal">
                                                                <i class="fa fa-trash-o"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
