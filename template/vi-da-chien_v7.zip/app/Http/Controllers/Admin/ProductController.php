<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Storage;

class ProductController extends Controller
{
    public function index(){
        return view('admin.product.index');
    }

    public function showCreate(){
        return view('admin.product.create');
    }

    public function store(Request $request){
        $data = $request->image_test;


        if(preg_match('/data:image\/(gif|jpeg|png);base64,(.*)/i', $data, $matches))
        {
            $imageType = $matches[1];
            $imageData = base64_decode($matches[2]);
            $image = getimagesizefromstring($imageData);

//            $image = imagecreatefromstring($imageData);
            $filename = time() . '.' . $imageType;
            file_put_contents($filename,$imageData);
//            Storage::disk('local')->put();
            $fileUpload = Storage::put('./hinh_anh', $image);
            dd($fileUpload);
//            if(imagepng($image, 'images/' . $filename))
//            {
//                echo json_encode(array('filename' => '/scripts/images/' . $filename));
//            } else {
//                throw new Exception('Could not save the file.');
//            }
        } else {
            throw new Exception('Invalid data URL.');
        }
        dd($request);
    }
}
