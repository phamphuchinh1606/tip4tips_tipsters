<div class="block left-module linklist">
    <p class="title_block">Danh mục sản phẩm</p>
    <div class="block_content">
        <!-- layered -->
        <div class="layered layered-category">
            <div class="layered-content">
                <ul class="tree-menu notStyle">
                    <li class=" has-child">
                        <span></span>
                        <a class="dropdown-toggle has-category parent " href="/" title="Mẹ và bé" target="_self">
                            <span class="">Mẹ và bé</span>
                        </a>

                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Đồng hồ" target="_self">
                            Đồng hồ
                        </a>
                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Túi ví" target="_self">
                            Túi ví
                        </a>
                    </li>
                    <li class=" has-child">
                        <span></span>
                        <a class="dropdown-toggle has-category parent " href="/" title="Thời trang nữ" target="_self">
                            <span class="">Thời trang nữ</span>
                        </a>

                    </li>
                    <li class=" has-child">
                        <span></span>
                        <a class="dropdown-toggle has-category parent " href="/" title="Thời trang nam" target="_self">
                            <span class="">Thời trang nam</span>
                        </a>

                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Mỹ phẩm" target="_self">
                            Mỹ phẩm
                        </a>
                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Mắt kính" target="_self">
                            Mắt kính
                        </a>
                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Deal giá sốc" target="_self">
                            Deal giá sốc
                        </a>
                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Sale tuần" target="_self">
                            Sale tuần
                        </a>
                    </li>
                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Trang sức" target="_self">
                            Trang sức
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ./layered -->
    </div>
</div>