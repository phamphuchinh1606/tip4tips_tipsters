<section id="homeProductBlock-5" class="control-block pdHomeBlock">
    <div class="container">
        <div class="row">
            <!-- BlockProduct5 _ Slide Banner & Product -->
            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 homeBlockLeft">
                <div class="wrapperBlockProduct">
                    <div class="homeBannerProduct blockslidebanner">

                        <!-- settings banner slide -->


                        <div class="item_banner imageHover">
                            <a href="#">
                                <img src="<?php echo e(asset('/images/guest/product_block/home_block_5.jpg')); ?>" alt="#"/>
                            </a>
                        </div>
                        <!-- settings banner slide -->
                        <!-- settings banner slide -->
                    </div>
                    <div class="heading-product">
						<span class="holder_header">
							<span class="line_title"></span>
						</span>
                        <h4>Sản phẩm giảm giá</h4>
                        <span class="holder_header">
							<span class="line_title"></span>
						</span>
                    </div>
                    <div class="woocommerce">
                        <?php
                        $arrayProduct = [];
                        for($i = 1; $i <= 5 ; $i++){
                            $product = new ArrayObject();
                            $product->product_name = 'Ví khắc tên ' . $i;
                            $product->product_price = number_format($i*100000);
                            $product->product_price_sale = number_format($i*120000);
                            $product->image = '/images/guest/product/product_sale/product_sale_'.$i.'.jpg';
                            array_push($arrayProduct,$product);
                        }
                        ?>
                        <div class="homeSlideProduct owlDesign notDots">
                            <?php $__currentLoopData = $arrayProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('guest.common.__product_show_item',['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- BlockPromotion5 & Banner Ads -->
            <div class="col-lg-3 col-md-3 hidden-sm hidden-xs homeBlockRight">
                
                <?php echo $__env->make('guest.home.partials.__block_menu_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="block-ads imageHover">
                    <a href="#">
                        <img alt="#"
                             src="https://theme.hstatic.net/1000244873/1000313408/14/img_banner_ads_5.png?v=1543"/>
                    </a>
                </div>

            </div>
        </div>
    </div>
</section>