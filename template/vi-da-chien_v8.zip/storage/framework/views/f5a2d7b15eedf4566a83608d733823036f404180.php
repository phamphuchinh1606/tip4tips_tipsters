<?php $__env->startSection('head.title','Ví Da Khắc Tên'); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>