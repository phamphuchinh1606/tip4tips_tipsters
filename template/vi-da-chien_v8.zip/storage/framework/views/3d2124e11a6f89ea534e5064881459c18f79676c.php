<section id="blogHome" class="blockSection blogHome">
    <div class="container">
        <div class="wapperBlogHome">
            <div class="featuredTitle">
                <a href="/blogs/news">
                    <h2>

                        Tin tức mới

                    </h2>
                </a>

                <p class="titleDesc">
                    Tin công nghệ, cập nhật tin tức nhanh nhất và mới nhất
                </p>

            </div>
            <div class="blogsList">

                <ul class="slideBlogHome owlDesign notDots notStyle">

                    <li class="articleItem">


                        <div class="insArticleLoop">
                            <div class="articlePostBody bg_w">
                                <div class="postThumbIMG relative imageHover">
                                    <a href="/blogs/news/thoi-trang-tuong-dong-cua-gigi-hadid-va-kendall-jenner">
                                        <img src="<?php echo e(asset('./images/guest/blog/new_1.jpg')); ?>" style="height:371px"
                                             alt="Thời trang tương đồng của Gigi Hadid và Kendall Jenner">
                                    </a>
                                    <div class="createdInfo">
                                        <ul class="notStyle">
                                            <li class="time"><i class="fa fa-calendar" aria-hidden="true"></i>
                                                <time>23/11/2017</time>
                                            </li>
                                            <li class="comment"><i class="fa fa-comments-o"
                                                                   aria-hidden="true"></i> <span>0</span></li>
                                            <li class="post"><i class="fa fa-pencil-square-o"
                                                                aria-hidden="true"></i> <span>ST Fashion</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="postDetail">
                                    <div class="detail clearfix">
                                        <h3>
                                            <a href="/blogs/news/thoi-trang-tuong-dong-cua-gigi-hadid-va-kendall-jenner"
                                               title="Thời trang tương đồng của Gigi Hadid và Kendall Jenner">VÍ BÓP DA BÒ – Loại da luôn được yêu thích NHẤT</a>
                                        </h3>
                                        <p>VÍ BÓP DA BÒ – Loại ví da luôn được yêu thích nhất, tại sao???? Vì sao da bò lại là nguyên vật liệu phổ biến […]</p>
                                        <a href="/blogs/news/thoi-trang-tuong-dong-cua-gigi-hadid-va-kendall-jenner"
                                           class="view" title="Xem thêm">Xem thêm <i
                                                    class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="articleItem">


                        <div class="insArticleLoop">
                            <div class="articlePostBody bg_w">
                                <div class="postThumbIMG relative imageHover">
                                    <a href="/blogs/news/cach-phoi-hoa-tiet-ke-mua-he-an-tuong-nhu-sao-ngoai">
                                        <img src="<?php echo e(asset('./images/guest/blog/new_2.jpg')); ?>" style="height: 371px"
                                             alt="Cách phối họa tiết kẻ mùa hè ấn tượng như sao ngoại">
                                    </a>
                                    <div class="createdInfo">
                                        <ul class="notStyle">
                                            <li class="time"><i class="fa fa-calendar" aria-hidden="true"></i>
                                                <time>23/11/2017</time>
                                            </li>
                                            <li class="comment"><i class="fa fa-comments-o"
                                                                   aria-hidden="true"></i> <span>0</span></li>
                                            <li class="post"><i class="fa fa-pencil-square-o"
                                                                aria-hidden="true"></i> <span>ST Fashion</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="postDetail">
                                    <div class="detail clearfix">
                                        <h3>
                                            <a href="/blogs/news/cach-phoi-hoa-tiet-ke-mua-he-an-tuong-nhu-sao-ngoai"
                                               title="Cách phối họa tiết kẻ mùa hè ấn tượng như sao ngoại">BÓP VÍ DA BÒ – Hãy chọn cho mình một nơi uy tín thân thiết.</a>
                                        </h3>
                                        <p>BÓP VÍ DA BÒ – HÃY CHỌN CHO MÌNH MỘT CỬA HÀNG ĐỒ DA UY TÍN THÂN THIẾT ! Bài viết này tôi viết tiếp cho […]</p>
                                        <a href="/blogs/news/cach-phoi-hoa-tiet-ke-mua-he-an-tuong-nhu-sao-ngoai"
                                           class="view" title="Xem thêm">Xem thêm <i
                                                    class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="articleItem">


                        <div class="insArticleLoop">
                            <div class="articlePostBody bg_w">
                                <div class="postThumbIMG relative imageHover">
                                    <a href="/blogs/news/chon-do-mua-he-che-khuyet-diem-canh-tay">
                                        <img src="<?php echo e(asset('./images/guest/blog/new_3.jpg')); ?>" style="height: 371px;"
                                             alt="Chọn đồ mùa hè che khuyết điểm cánh tay">
                                    </a>
                                    <div class="createdInfo">
                                        <ul class="notStyle">
                                            <li class="time"><i class="fa fa-calendar" aria-hidden="true"></i>
                                                <time>23/11/2017</time>
                                            </li>
                                            <li class="comment"><i class="fa fa-comments-o"
                                                                   aria-hidden="true"></i> <span>0</span></li>
                                            <li class="post"><i class="fa fa-pencil-square-o"
                                                                aria-hidden="true"></i> <span>ST Fashion</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="postDetail">
                                    <div class="detail clearfix">
                                        <h3><a href="/blogs/news/chon-do-mua-he-che-khuyet-diem-canh-tay"
                                               title="Chọn đồ mùa hè che khuyết điểm cánh tay">Chọn đồ mùa hè
                                                che khuyết điểm cánh tay</a></h3>
                                        <p>Dưới đây là bí quyết giúp bạn thoải mái diện những thiết kế không
                                            tay, 2 dây mát mẻ ngày hè mà vẫn che được khuyết điểm cánh tay
                                            kém...</p>
                                        <a href="/blogs/news/chon-do-mua-he-che-khuyet-diem-canh-tay"
                                           class="view" title="Xem thêm">Xem thêm <i
                                                    class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="articleItem">


                        <div class="insArticleLoop">
                            <div class="articlePostBody bg_w">
                                <div class="postThumbIMG relative imageHover">
                                    <a href="/blogs/news/phoi-quan-jeans-cap-cao-theo-phong-cach-thap-nien-1970">
                                        <img src="<?php echo e(asset('./images/guest/blog/new_4.jpg')); ?>"
                                             alt="Phối quần jeans cạp cao theo phong cách thập niên 1970">
                                    </a>
                                    <div class="createdInfo">
                                        <ul class="notStyle">
                                            <li class="time"><i class="fa fa-calendar" aria-hidden="true"></i>
                                                <time>23/11/2017</time>
                                            </li>
                                            <li class="comment"><i class="fa fa-comments-o"
                                                                   aria-hidden="true"></i> <span>0</span></li>
                                            <li class="post"><i class="fa fa-pencil-square-o"
                                                                aria-hidden="true"></i> <span>ST Fashion</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="postDetail">
                                    <div class="detail clearfix">
                                        <h3>
                                            <a href="/blogs/news/phoi-quan-jeans-cap-cao-theo-phong-cach-thap-nien-1970"
                                               title="Phối quần jeans cạp cao theo phong cách thập niên 1970">Phối
                                                quần jeans cạp cao theo phong cách thập niên 1970</a></h3>
                                        <p>Quần jeans cạp cao xuất hiện từ những năm 1970 đã quay trở lại, được
                                            nhiều tín đồ thời trang yêu thích và phối cá tính theo hơi hướng
                                            hiện...</p>
                                        <a href="/blogs/news/phoi-quan-jeans-cap-cao-theo-phong-cach-thap-nien-1970"
                                           class="view" title="Xem thêm">Xem thêm <i
                                                    class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="articleItem">


                        <div class="insArticleLoop">
                            <div class="articlePostBody bg_w">
                                <div class="postThumbIMG relative imageHover">
                                    <a href="/blogs/news/8-cong-thuc-phoi-do-mua-he-cua-karlie-kloss">
                                        <img src="<?php echo e(asset('/images/guest/blog/new_5.jpg')); ?>"
                                             alt="8 công thức phối đồ mùa hè của Karlie Kloss">
                                    </a>
                                    <div class="createdInfo">
                                        <ul class="notStyle">
                                            <li class="time"><i class="fa fa-calendar" aria-hidden="true"></i>
                                                <time>23/11/2017</time>
                                            </li>
                                            <li class="comment"><i class="fa fa-comments-o"
                                                                   aria-hidden="true"></i> <span>0</span></li>
                                            <li class="post"><i class="fa fa-pencil-square-o"
                                                                aria-hidden="true"></i> <span>ST Fashion</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="postDetail">
                                    <div class="detail clearfix">
                                        <h3><a href="/blogs/news/8-cong-thuc-phoi-do-mua-he-cua-karlie-kloss"
                                               title="8 công thức phối đồ mùa hè của Karlie Kloss">8 công thức
                                                phối đồ mùa hè của Karlie Kloss</a></h3>
                                        <p>Một số bí quyết nhỏ giúp chân dài nổi tiếng luôn trẻ trung, tươi tắn
                                            và cá tính ngày hè.Crop top + váy đồng màu: Karlie diện crop top ôm
                                            sát...</p>
                                        <a href="/blogs/news/8-cong-thuc-phoi-do-mua-he-cua-karlie-kloss"
                                           class="view" title="Xem thêm">Xem thêm <i
                                                    class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                </ul>

            </div>
        </div>
    </div>
</section>