<?php $__env->startSection('head.title','Ví Da Khắc Tên'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href='<?php echo e(asset('/css/guest/plugins/pages.css?v=1543')); ?>' rel='stylesheet' type='text/css'  media='all'  />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <section id="insContactPage">
        
        <?php echo $__env->make('guest.common.__breadcrumb_show',['contact' => 'contact'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container">
            <div class="wrapperContactPage">
                <div class="headingPage">
                    <h1 class="title">Liên hệ</h1>
                </div>

                <div class="ggMap">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.3073412298813!2d106.65401811422637!3d10.787756192313843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752ecbca1d78d1%3A0xba79696ed207d8fa!2zNTYgVsOibiBDw7RpLCA3LCBUw6JuIELDrG5oLCBI4buTIENow60gTWluaCwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1500977912224" width="600" height="450" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                </div>

                <div class="contactList">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 pull-left infoForm">
                            <div class="wrapForm">
                                <h3 class="name-head">
                                    <span>Bạn cần hỗ trợ? Hãy gửi thông tin cho chúng tôi</span>
                                </h3>
                                <form accept-charset="UTF-8" action="/contact" class="contact-form" method="post">
                                    <input name="form_type" type="hidden" value="contact">
                                    <input name="utf8" type="hidden" value="✓">


                                    <div class="row">
                                        <div class="col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <span class="ico"><i class="fa fa-user-circle-o" aria-hidden="true"></i></span>
                                                <input required="" type="text" id="contactFormName" class="form-control input-lg" name="contact[name]" placeholder="Tên của bạn" autocapitalize="words" value="">
                                            </div>
                                            <div class="form-group">
                                                <span class="ico"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                                <input required="" type="text" id="contactFormPhone" class="form-control input-lg" name="contact[phone]" placeholder="Tên của bạn" autocapitalize="words" value="">
                                            </div>
                                            <div class="form-group">
                                                <span class="ico"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                                <input required="" type="email" name="contact[email]" placeholder="Email của bạn" id="contactFormEmail" class="form-control input-lg" autocorrect="off" autocapitalize="off" value="">
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label for="contactFormMessage" class="sr-only">Nội dung</label>
                                                <textarea required="" rows="6" name="contact[body]" class="form-control" placeholder="Viết bình luận" id="contactFormMessage"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-xs-12">
                                            <button type="submit" class="btn btn-outline insButton">Gửi thông tin</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-xs-12 pull-right infoText">
                            <div class="wrap">
                                <h3 class="name-head">	Chúng tôi ở đây</h3>
                                <p>Công ty ví da khắc tên cao cấp</p>
                                <ul class="info-address notStyle">
                                    <li>
                                        <i class="glyphicon glyphicon-map-marker"></i>
                                        <span>60/30 Đồng Đen ,phường 14 ,Quận Tân Bình</span>
                                    </li>
                                    <li>
                                        <i class="glyphicon glyphicon-envelope"></i>
                                        <span>phanchien@gmail.com</span>
                                    </li>

                                    <li>
                                        <i class="glyphicon glyphicon-phone-alt"></i>
                                        <span>0932 373 807</span>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>