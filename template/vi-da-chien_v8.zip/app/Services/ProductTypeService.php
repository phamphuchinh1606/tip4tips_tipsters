<?php

namespace App\Services;

use App\Common\AppCommon;

class ProductTypeService extends BaseService{

    public function create($productTypeName, $isPublic){
        return $this->productTypeLogic->create($productTypeName, $isPublic);
    }

    public function createChildren($productTypeId,$productTypeName, $isPublic){
        return $this->productTypeLogic->createChildren($productTypeId,$productTypeName, $isPublic);
    }

    public function update($productTypeId,$productTypeName, $isPublic){
        $this->productTypeLogic->update($productTypeId,$productTypeName, $isPublic);
    }

    public function findId($productTypeId){
        return $this->productTypeLogic->findId($productTypeId);
    }

    public function getAll(){
        $listProductType = $this->productTypeLogic->getAll();
        foreach ($listProductType as $productType){
            $productType->public_name = AppCommon::namePublicProductType($productType->is_public);
            $productType->public_class = AppCommon::classPublicProductType($productType->is_public);
        }
        return $listProductType;
    }

    public function getAllNotParent(){
        $listProductType = $this->productTypeLogic->getAllNotParent();
        foreach ($listProductType as $productType){
            $productType->public_name = AppCommon::namePublicProductType($productType->is_public);
            $productType->public_class = AppCommon::classPublicProductType($productType->is_public);
        }
        return $listProductType;
    }

    public function getByParentId($productTypeId){
        $listProductType = $this->productTypeLogic->getByParentId($productTypeId);
        foreach ($listProductType as $productType){
            $productType->public_name = AppCommon::namePublicProductType($productType->is_public);
            $productType->public_class = AppCommon::classPublicProductType($productType->is_public);
        }
        return $listProductType;
    }

    public function delete($productTypeId){
        return $this->productTypeLogic->delete($productTypeId);
    }
}
