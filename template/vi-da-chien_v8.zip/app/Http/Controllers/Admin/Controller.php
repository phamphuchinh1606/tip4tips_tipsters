<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use App\Services\ProductTypeService;
use Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $productTypeService;

    public function __construct(ProductTypeService $productTypeService)
    {
        $this->productTypeService = $productTypeService;
    }

    protected function viewAdmin($viewName,$arrayData = []){
        return View('admin.'.$viewName, $arrayData);
    }

    public function uploadImageQuillEditor(Request $request){
        $data = $request->src_image;
        $dataJson = ['status' => 'error',
            'src_image' => ''];
        if(preg_match('/data:image\/(gif|jpeg|png);base64,(.*)/i', $data, $matches))
        {
            $imageType = $matches[1];
            $imageData = base64_decode($matches[2]);
            $image = getimagesizefromstring($imageData);
            $filename = time() . '.' . $imageType;
            file_put_contents($filename,$imageData);
            Storage::disk('local')->put('images_editor/'.$filename, $image);
            $dataJson = ['status' => 'success',
                'src_image' => asset($filename)];
        } else {
            throw new Exception('Invalid data URL.');
        }
        return response()->json($dataJson);
    }
}
