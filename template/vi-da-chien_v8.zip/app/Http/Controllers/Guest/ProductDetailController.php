<?php

namespace App\Http\Controllers\Guest;

use Illuminate\Http\Request;
use StdClass;

class ProductDetailController extends Controller
{
    public function index(){
        return view('guest.product.product_detail');
    }

    public function quickViewProduct(){
        $product = new stdClass();
        $product->title = "Ví da khắc tên cao cấp 01";
        $product->metadescription = "Mẫu giày cao gót CG09030 là lựa chọn hàng đầu của các cô gái yêu thích phong cách sang trọng và thanh lịch, cùng nàng tỏa sáng mọi lúc mọi nơi.";
        $product->options = [];
        $product->vendor = "vendor";
        $product->price = "43500000";
        $product->compare_at_price = "50000000";
        $product->description = "Bạn đang quan tâm đến ví da khắc tên! Thế bạn có biết những gì người ta thường hay khắc trên ví da không? Có vô số thứ người ta có thể khắc lên ví, vậy thì nên khắc chữ gì lên ví da? Nào là tên, ảnh chân dung, 12 con giáp, logo công an,… đều khắc được cả.";
        $product->url = route('product_detail');
        $product->images = [asset('images/guest/product/vinam/product_1.jpg'),
            asset('images/guest/product/vinam/product_2.jpg'),
            asset('images/guest/product/vinam/product_3.jpg'),
            asset('images/guest/product/vinam/product_4.jpg'),
            asset('images/guest/product/vinam/product_5.jpg')
        ];
        $product->featured_image = asset('images/guest/product/vinam/product_1.jpg');
        $variant = new StdClass();
        $variant->available = true;
        $variant->compare_at_price = "51000000";
        $variant->inventory_quantity = "1";
        $variant->price = "43500000";
        $variant->sku = "CG09030";
        $variant->id = "1019623681";
        $variant->title = "Ví da khắc tên cao cấp 01";
        $product->variants = [$variant];
        return response()->json($product);
    }
}
