<?php
namespace App\Http\Services;

class BaseService
{
}
