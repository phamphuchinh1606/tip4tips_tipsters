<?php 
//    use App\Common\Common;
//    use App\Common\Utils;
?>
@extends('layouts.master')
@section('title', 'Event Beats')
{{--@section('body.breadcrumbs')--}}
    {{--{{ Breadcrumbs::render('dashboard') }}--}}
{{--@stop--}}
@section('styles')
    <link href="{{asset('css/jquery.scrollbar.css')}}" rel="stylesheet" type="text/css">
    <style>
        .list-table{
            padding: 0;
            border-top: 1px solid #fcc85f;
        }
        ul{
            display: block;
            list-style-type: disc;
            -webkit-margin-before: 1em;
            -webkit-margin-after: 1em;
            -webkit-margin-start: 0px;
            -webkit-margin-end: 0px;
            -webkit-padding-start: 40px;
        }
        div#rightbar div.list{
            width: 100%;
            line-height: 18px;
        }
        .list-table li {
            border-bottom: 1px solid #fcc85f;
            overflow: hidden;
            position: relative;
        }
        ul li {
            list-style: none;
        }
        li {
            display: list-item;
            text-align: -webkit-match-parent;
        }
        .date-content {
            width: 90px;
            text-align: center;
            float: left;
            height: 142px;
        }
        .date-content .big-calendar-icon {
            margin-top: 52px;
        }
        .big-calendar-icon {
            width: 50px;
            height: 32px;
            background: url(../images/big-calendar-icon.jpg) no-repeat;
            margin: 0 auto;
            padding: 0;
        }
        .big-calendar-icon .day {
            height: 13px;
            margin: 1px 0;
            text-align: center;
            color: #080808;
            font-size: 11px;
            white-space: nowrap;
        }
        .big-calendar-icon .month {
            height: 17px;
            margin: 0;
            text-align: center;
            color: #fff;
            font-size: 11px;
            white-space: nowrap;
        }
        div {
            display: block;
        }
        .image-content {
            width: 160px;
            float: left;
            color: #757576;
            padding-bottom: 5px;
        }
        .image-content .img-wrap {
            border: 3px solid #ffe085;
            width: 136px;
            height: 74px;
            margin: 22px auto 10px;
            text-align: center;
        }
        .image-content .industry-line, .image-content .type-line {
            font-size: 11px;
            padding-left: 10px;
        }
        .image-content .industry-line, .image-content .type-line {
            font-size: 11px;
            padding-left: 10px;
        }
        .des-content {
            width: 260px;
            padding: 22px 20px;
            float: left;
        }
        .des-content h4 {
            color: #0e4289;
            padding-bottom: 10px;
            font-size: 13px;
            text-align: left;
            overflow: hidden;
        }
        .des-content .des-detail {
            display: none;
        }
        .des-content .des-place {
            color: #194291;
            padding-top: 10px;
        }
        .share-content {
            float: right;
            padding-top: 65px;
            padding-right: 0;
        }
        .gobtn a {
            display: block;
            float: left;
        }

        .green-check {
            position: relative;
            oveflow: visible;
            margin-right: 15px;
            margin-right: 5px;
        }
        .button-silver-style {
            background: #f7f6f4;
            border: 1px solid #c6c6c6;
            padding: 3px 5px;
            text-decoration: none !important;
        }
    </style>
@stop
@section('javascript')

@stop
@section('content')
    <!-- Main row -->
    <div class="row dashboard">
        <div class="box box-list">
            <div class="box-header clearfix">
                <h3 class="box-title">@yield('title')</h3>
                <a href="{{route('venue.create')}}" class="btn btn-md btn-primary pull-right"><i class="fa fa-plus"></i> New Venue</a>
            </div>
        </div>
        <div class="box-body">
            <ul class="list-table">
                <li>
                    <div class="date-content">
                        <div class="big-calendar-icon">
                            <div class="day">
                                06						</div>
                            <div class="month">
                                Sep						</div>
                        </div>
                        <span style="font-size: 11px;clear: both; margin-top: 5px;color: #080808; white-space: nowrap; display: block; margin-top: 5px;">09:00 am</span>
                    </div>
                    <div class="image-content">
                        <div class="img-wrap">
                            <a title="International Travel Expo Ho Chi Minh City 2018" href="/saigon/events/international-travel-expo-ho-chi-minh-city-2018-september-6th-2018">
                                <img class="item-thumb1" width="136" height="74" src="/uploads/events/136x74/36596066_973394179501499_6695560582298337280_o.jpg" alt="International Travel Expo Ho Chi Minh City 2018">
                            </a>
                        </div>
                        <div class="industry-line">
                            Industry: <a title="Tourism / Hospitality / Entertainment / Travel" class="vtip greyout" href="/saigon/events?page=1&amp;limit=25&amp;sort=date&amp;list=future&amp;event_industry_id=42">Tourism </a>					</div>
                        <div class="type-line">
                            Type: <a title="Exhibitions" class="vtip greyout" href="/saigon/events?page=1&amp;limit=25&amp;sort=date&amp;list=future&amp;event_type_id[]=4">Exhibitions</a>					</div>
                    </div>
                    <div class="des-content" style="width: 298px;">
                        <h4>
                            <a class="item-title1" href="/saigon/events/international-travel-expo-ho-chi-minh-city-2018-september-6th-2018" title="International Travel Expo Ho Chi Minh City 2018">
                                International Travel Expo Ho Chi Minh City 2018						</a>
                        </h4>
                        <p class="item-descript1 des-detail">
                            The International Travel Expo Ho Chi Minh City (ITE HCMC), regarded as Vietnam's foremost tourism trade event, has been an annual sho...					</p>
                        <p class="des-place">
                            <a class="blue" href="/saigon/venues/saigon-exhibition-and-convention-center-secc" title="Saigon Exhibition and Convention Center (SECC)">
                                Saigon Exhibition and Convention Center (SECC)						</a>
                        </p>
                    </div>
                    <div class="gobtn share-content">
                        <a rev="" class="sharebtn button-silver-style green-check" href="javascript:void(0)" rel="international-travel-expo-ho-chi-minh-city-2018-september-6th-2018">
                            I'm going
                        </a>
                        <a class="fb-share-btn button-silver-style share-button" href="javascript:void(0)" rel="1">Share</a>
                    </div>
                </li>
                <li>
                    <div class="date-content">
                        <div class="big-calendar-icon">
                            <div class="day">
                                07						</div>
                            <div class="month">
                                Sep						</div>
                        </div>
                        <span style="font-size: 11px;clear: both; margin-top: 5px;color: #080808; white-space: nowrap; display: block; margin-top: 5px;">03:36 pm</span>
                    </div>
                    <div class="image-content">
                        <div class="img-wrap">
                            <a title="Fall 2018 Ho Chi Minh City EB-5 &amp; Global Programs Expo" href="/saigon/events/fall-2018-ho-chi-minh-city-eb-5-and-global-programs-expo-september-7th-2018">
                                <img class="item-thumb2" width="136" height="74" src="/uploads/events/136x74/https _cdn.evbuc.com_images_42005617_241781030296_1_original.jpg" alt="Fall 2018 Ho Chi Minh City EB-5 &amp; Global Programs Expo">
                            </a>
                        </div>
                        <div class="industry-line">
                            Industry: <a title="Other" class="vtip greyout" href="/saigon/events?page=1&amp;limit=25&amp;sort=date&amp;list=future&amp;event_industry_id=49">Other</a>					</div>
                        <div class="type-line">
                            Type: <a title="Festivals" class="vtip greyout" href="/saigon/events?page=1&amp;limit=25&amp;sort=date&amp;list=future&amp;event_type_id[]=9">Festivals</a>					</div>
                    </div>
                    <div class="des-content" style="width: 298px;">
                        <h4>
                            <a class="item-title2" href="/saigon/events/fall-2018-ho-chi-minh-city-eb-5-and-global-programs-expo-september-7th-2018" title="Fall 2018 Ho Chi Minh City EB-5 &amp; Global Programs Expo">
                                Fall 2018 Ho Chi Minh City EB-5 &amp; Global Programs Expo						</a>
                        </h4>
                        <p class="item-descript2 des-detail">
                            With the Vietnam EB-5 market continuing to be one of the fastest growing in the world, EB5 Investors Magazine is returning to Ho Chi ...					</p>
                        <p class="des-place">
                            <a class="blue" href="/saigon/venues/park-hyatt-saigon" title="Park Hyatt Saigon">
                                Park Hyatt Saigon						</a>
                        </p>
                    </div>
                    <div class="gobtn share-content">
                        <a rev="" class="sharebtn button-silver-style green-check" href="javascript:void(0)" rel="fall-2018-ho-chi-minh-city-eb-5-and-global-programs-expo-september-7th-2018">
                            I'm going
                        </a>
                        <a class="fb-share-btn button-silver-style share-button" href="javascript:void(0)" rel="2">Share</a>
                    </div>
                </li>

            </ul>
        </div>
    </div>
@endsection
