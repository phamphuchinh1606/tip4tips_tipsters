<?php

namespace App\Http\Controllers\Guest;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index(){
        return view('guest.blog.blog');
    }

    public function detail(){
        return view('guest.blog.blog_detail');
    }
}
