<?php $__env->startSection('head.title','Danh Sách Tin Tức'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/jquery.dataTables.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/dataTables.bootstrap4.js')); ?>" class="view-script"></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh Sách Tin Tức
                            <div class="card-header-actions">
                                <a class="btn btn-block btn-outline-primary active" href="<?php echo e(route('admin.blog.create')); ?>">
                                    Tạo mới
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                            <tr role="row">
                                                <th class="sorting_asc">
                                                    STT
                                                </th>
                                                <th class="sorting">
                                                    Hình ảnh
                                                </th>
                                                <th class="sorting">
                                                    Tiêu đề
                                                </th>
                                                <th class="sorting">
                                                    Ngày đăng
                                                </th>
                                                <th class="sorting">
                                                    Tình trạng
                                                </th>
                                                <th class="sorting">
                                                    Actions
                                                </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            
                                                
                                                    
                                                        
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        
                                                            
                                                        
                                                        
                                                            
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                            
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>