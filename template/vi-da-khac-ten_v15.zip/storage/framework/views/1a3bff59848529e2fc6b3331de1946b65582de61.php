<select class="form-control" id="vendor" name="<?php echo e($selectName); ?>">
    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($vendor->id); ?>" <?php if(isset($defaultValue) && $defaultValue == $vendor->id): ?> selected <?php endif; ?>>
            <?php echo e($vendor->vendor_name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>