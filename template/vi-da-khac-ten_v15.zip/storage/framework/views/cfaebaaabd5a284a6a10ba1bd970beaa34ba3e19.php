<?php use App\Common\Constant; ?>



<?php $__env->startSection('head.title','Cài Đặt Slider Banner'); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div class="row">
                <div class="col-sm-12 col-xl-6">
                    <div class="card list-image">
                        <div class="card-header">
                            <i class="fa fa-align-justify"></i> Danh Sách Ảnh Banner
                        </div>
                        <div class="card-body">
                            <div class="carousel slide" data-ride="carousel">
                                <div class="form-group row">
                                    <div class="col-md-4">
                                        <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseAddImage" aria-expanded="true" aria-controls="collapseExample" data-placement="top" title="" data-original-title="Them Hinh">
                                            <i class="fa fa-upload fa-lg"></i>
                                        </button>
                                    </div>
                                    <div class="col-md-8 collapse" id="collapseAddImage">
                                        <form action="<?php echo e(route('admin.setting.banner.create')); ?>" method="post"  enctype="multipart/form-data" id="form">
                                            <?php echo csrf_field(); ?>
                                            <div class="text-right p-sm-1" id="btn_add_image" style="display: none">
                                                <button type="submit" class="btn btn-primary">Thêm hình</button>
                                            </div>
                                            <div class="upload__area-image">
                                                    <span>
                                                        <img id="imgAdd" src="http://beats-city.amagumolabs.io/images/upload/no_image_available.jpg">
                                                        <label for="imageFileAdd">Upload image</label>
                                                    </span>
                                                <p><small>(Please upload a file of type: jpeg, png, jpg, gif, svg. ( width: 893px , height: 465px)</small></p>
                                            </div>
                                            <div class="form__upload">
                                                <div class="form-inline-simple">
                                                    <input type="file" name="src_image" class="form-control imgAnchorInput" id="imageFileAdd" onchange="loadFileImage(event)">
                                                </div>
                                                <script>
                                                    var loadFileImage = function(event) {
                                                        var output = document.getElementById('imgAdd');
                                                        output.src = URL.createObjectURL(event.target.files[0]);
                                                        document.getElementById('btn_add_image').style.display = 'block';
                                                    };
                                                </script>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <img src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$banner->src_image)); ?>">
                                            <div>
                                                <a data-toggle="modal" class="nav-link delete-image anchorClick" data-url="<?php echo e(route('admin.setting.banner.delete',['id' => $banner->id])); ?>" data-name="Hình ảnh" href="#deleteModal">
                                                    Xóa Ảnh
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(count($banners) > 0): ?>
                    <div class="col-sm-12 col-xl-6">
                        <div class="card">
                            <div class="card-header">
                                <i class="fa fa-align-justify"></i>Hình Ảnh Banner
                            </div>
                            <div class="card-body">
                                <div class="carousel slide" id="carouselExampleIndicators" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="<?php if($index == 0): ?> active <?php endif; ?>" data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>"></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                    <div class="carousel-inner">
                                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php if($index == 0): ?> active <?php endif; ?>">
                                                <img class="d-block w-100" alt="Image Banner" src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$banner->src_image)); ?>" data-holder-rendered="true">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>