<?php

namespace App\Services;

use App\Common\AppCommon;
use App\Common\Constant;
use Illuminate\Http\Request;

class SettingService extends BaseService{

    public function getBannerAll(){
        return $this->settingLogic->getBannerAll();
    }

    public function createBanner(Request $request){
        $fileImage = $request->file('src_image');
        if(isset($fileImage)){
            $srcImage = AppCommon::moveImage($fileImage, Constant::$PATH_FOLDER_UPLOAD_IMAGE_BANNER);
            return $this->settingLogic->createBanner($srcImage);
        }
        return null;
    }

    public function deleteBanner($bannerId){
        $this->settingLogic->deleteBanner($bannerId);
    }

    //Start Top Banner
    public function getTopBannerAll(){
        return $this->settingLogic->getTopBannerAll();
    }

    public function createTopBanner(Request $request){
        $fileImage = $request->file('src_image');
        if(isset($fileImage)){
            $srcImage = AppCommon::moveImage($fileImage, Constant::$PATH_FOLDER_UPLOAD_IMAGE_TOP_BANNER);
            return $this->settingLogic->createTopBanner($srcImage);
        }
        return null;
    }

    public function deleteTopBanner($bannerId){
        $this->settingLogic->deleteTopBanner($bannerId);
    }
    //End Top banner

    //Start Tag Key
    public function getTagAll(){
        return $this->settingLogic->getTagAll();
    }

    public function getTagByTagType($tagTypeId){
        return $this->settingLogic->getTagByTagType($tagTypeId);
    }

    public function createTag(Request $request){
        $tagName = $request->tag_name;
        $productTypeId = $request->product_type_id;
        $sortNumber = $request->sort_number;
        if(isset($sortNumber)){
            $sortNumber = 1;
        }
        $tabTypeId = $request->tab_type;
        $this->settingLogic->createTag($tabTypeId,$productTypeId,$tagName,$sortNumber);
        return null;
    }

    public function deleteTag($tagId){
        $this->settingLogic->deleteTag($tagId);
    }
    //End Tag Key
}
