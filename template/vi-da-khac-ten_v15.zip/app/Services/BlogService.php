<?php

namespace App\Services;
use Illuminate\Http\Request;

class BlogService extends BaseService{

    public function getAll(){
        return $this->blogLogic->getAll();
    }

    public function create(Request $request){

        $this->blogLogic->create();
    }

    public function update($blogId, $vendorName){
        $this->blogLogic->update($blogId, $vendorName);
    }

    public function findId($blogId){
        return $this->blogLogic->findId($blogId);
    }

    public function delete($blogId){
        $this->blogLogic->delete($blogId);
    }
}
