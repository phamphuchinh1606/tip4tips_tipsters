<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index(){
        $blogs = $this->blogService->getAll();
        return $this->viewAdmin('blog.index',[
            'blogs' => $blogs
        ]);
    }

    public function showCreate(){
        return $this->viewAdmin('blog.create');
    }

    public function store(Request $request){
        $vendorName = $request->vendor_name;
        $this->vendorService->create($vendorName);
        return redirect()->route('blog.index');
    }

    public function showUpdate($id){
        $vendor = $this->vendorService->findId($id);
        return $this->viewAdmin('blog.update',[
            'vendor' => $vendor
        ]);
    }

    public function update($id, Request $request){
        $vendorName = $request->vendor_name;
        $this->vendorService->update($id, $vendorName);
        return redirect()->route('admin.blog.index');
    }
}
