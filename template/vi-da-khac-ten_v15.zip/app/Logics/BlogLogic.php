<?php

namespace App\Logics;

use App\Common\Constant;
use App\Models\Blog;

class BlogLogic extends BaseLogic{
    public function getAll(){
        return Blog::where('is_delete',Constant::$DELETE_FLG_OFF)
            ->orderBy('id','asc')->get();
    }

    public function create($params = []){
        $blog = new Blog();
        $blog->blog_title = $params['blogTitle'];
        $blog->slug = $params['slug'];
        $blog->post_date = $params['post_date'];
        $blog->blog_content = $params['blogContent'];
        $blog->is_public = $params['isPublic'];
        return $blog->save();
    }

    public function update($blogId, $params){
        $blog = Blog::find($blogId);
        if(isset($blog)){
            $blog->blog_title = $params['blogTitle'];
            $blog->slug = $params['slug'];
            $blog->post_date = $params['post_date'];
            $blog->blog_content = $params['blogContent'];
            $blog->is_public = $params['isPublic'];
            if(isset($params['blogImage'])){
                $blog->blog_image = $params['blogImage'];
            }
            $blog->save();
        }
    }

    public function findId($blogId){
        return Blog::find($blogId);
    }

    public function delete($blogId){
        $blog = Blog::find($blogId);;
        if(isset($blog)){
            $blog->is_delete = Constant::$DELETE_FLG_ON;
            $blog->save();
        }
    }
}
