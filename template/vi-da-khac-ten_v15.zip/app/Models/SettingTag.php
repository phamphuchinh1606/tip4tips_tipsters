<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingTag extends Model
{
    //
}
