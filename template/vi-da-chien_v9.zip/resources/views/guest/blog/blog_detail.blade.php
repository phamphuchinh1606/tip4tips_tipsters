@extends('guest.layouts.master')

@section('head.title','Ví Da Khắc Tên')

@section('head.css')
    <link href='{{ asset('/css/guest/plugins/pages.css?v=1543') }}' rel='stylesheet' type='text/css'  media='all'  />
@endsection

@section('body.content')
    <section id="insBlogPage">
        {{--Breadcrumb--}}
        @include('guest.common.__breadcrumb_show',['blogDetail' => 'blogDetail'])

        <div class="container">
            <div class="wrapperArticlePage">
                <div class="row">
                    <div class="col-md-9 col-sm-8 col-xs-12">
                        <div class="insCtMain">
                            <div class="main_article bg_w">
                                <div class="head">
                                    <h1>
                                        Chọn đồ mùa hè che khuyết điểm cánh tay
                                    </h1>
                                    <div class="info_edu">
                                        <ul>
                                            <li><i class="fa fa-book" aria-hidden="true"></i> ST Fashion</li>
                                            <li><i class="fa fa-tags" aria-hidden="true"></i> <a href="Tin tức">Tin tức</a></li>
                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> 23/11/2017</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="body-content">
                                    <p class="the-article-summary">Dưới đây là bí quyết giúp bạn thoải mái diện những thiết kế không tay, 2 dây mát mẻ ngày hè mà vẫn che được khuyết điểm cánh tay kém xinh.</p><div class="the-article-body"><table class="picture mce-item-table" align="center"><tbody><tr><td class="pic"><img alt="Chon do mua he che khuyet diem canh tay hinh anh 1" src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_1.jpg" data-mce-src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_1.jpg"></td></tr><tr><td class="pCaption caption"><strong>Đừng mặc áo quá ôm:&nbsp;</strong>Một chiếc áo quá ôm không chỉ khiến bạn cảm thấy không thoải mái mà còn dễ làm lộ các khuyết điểm như vùng mỡ thừa xấu xí ở lưng, nách và tạo sự chú ý vào phần cánh tay không đẹp. Hãy chọn những chiếc áo không tay hơi rộng, chúng giúp bạn trông nhẹ nhàng và sang trọng hơn.</td></tr></tbody></table><table class="picture mce-item-table" align="center"><tbody><tr><td class="pic"><img alt="Chon do mua he che khuyet diem canh tay hinh anh 2" src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_2.jpg" data-mce-src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_2.jpg"></td></tr><tr><td class="pCaption caption"><strong>Tay áo không khoét quá sâu hoặc quá cao:&nbsp;</strong>Hãy đảm bảo bạn có thể dễ dàng hoạt động và không làm lộ phần áo lót bên trong.</td></tr></tbody></table><table class="picture mce-item-table" align="center"><tbody><tr><td class="pic"><img alt="Chon do mua he che khuyet diem canh tay hinh anh 3" src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_3.jpg" data-mce-src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_3.jpg"></td></tr><tr><td class="pCaption caption"><strong>Những thiết kế trễ vai:&nbsp;</strong>Item này đang là xu hướng được ưa chuộng vào mùa hè không chỉ bởi sự ngọt ngào, nữ tính mà chúng còn giúp bạn che đi khuyết điểm cánh tay hiệu quả.</td></tr></tbody></table><table class="picture mce-item-table" align="center"><tbody><tr><td class="pic"><img alt="Chon do mua he che khuyet diem canh tay hinh anh 4" src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_4.jpg" data-mce-src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_4.jpg"></td></tr><tr><td class="pCaption caption"><strong>Áo cổ chữ V:&nbsp;</strong>Món đồ này sẽ làm lộ nhiều vùng da từ cổ đến ngực hơn, tạo sự chú ý vào khu vực này và phân tán khỏi phần cánh tay mà bạn luôn muốn che đi.</td></tr></tbody></table><table class="picture mce-item-table" align="center"><tbody><tr><td class="pic"><img alt="Chon do mua he che khuyet diem canh tay hinh anh 5" src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_5.jpg" data-mce-src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_5.jpg"></td></tr><tr><td class="pCaption caption"><strong>Trang phục lưới hoặc cut-out:&nbsp;</strong>Những phần khoét, cắt này sẽ thu hút người đối diện khi nhìn vào bạn. Hãy chọn đầm hoặc áo cut-out ở những bộ phận nổi bật giúp bạn tự tin như eo hoặc vùng xương quai xanh.</td></tr></tbody></table><table class="picture mce-item-table" align="center"><tbody><tr><td class="pic"><img alt="Chon do mua he che khuyet diem canh tay hinh anh 6" src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_6.jpg" data-mce-src="http://img.v3.news.zdn.vn/w660/Uploaded/cqxrcajwp/2016_06_20/che_khuyet_diem_doi_tay_6.jpg"></td></tr><tr><td class="pCaption caption"><strong>Áo khoác mỏng:&nbsp;</strong>Những chiếc áo khoác chất liệu mỏng nhẹ như voan hay cotton mỏng sẽ cho bạn hiệu quả tốt nhất. Áo khoác kimono là một gợi ý. Với phong cách này, bạn nên chọn lựa màu sắc và kiểu dáng càng đơn giản càng tốt.</td></tr></tbody></table></div>
                                </div>
                                <div class="clearfix"></div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 hidden-xs ba_sidebar">
                        <aside id="insBlogSidebar">
                            <div class="right_sidebar">
                                <div class="all_right_widgets">
                                    <div class="sing_right_widget">
                                        <h2>Bài viết mới nhất</h2>
                                        <div class="sing_right_widg_content">
                                            <ul class="lat_news_right">

                                                <li class="newItem">
                                                    <div class="wrap clearfix">
                                                        <a href="/blogs/news/thoi-trang-tuong-dong-cua-gigi-hadid-va-kendall-jenner">
                                                            <img src="https://file.hstatic.net/1000244873/article/blog2_3f69220f25d34aa68b894d2c5a942801_large.jpg" alt="Thời trang tương đồng của Gigi Hadid và Kendall Jenner">
                                                        </a>
                                                        <div class="lat_news_right_con">
                                                            <h3><a href="/blogs/news/thoi-trang-tuong-dong-cua-gigi-hadid-va-kendall-jenner">Thời trang tương đồng của...</a></h3>
                                                            <h4>23/11/2017</h4>
                                                        </div>
                                                    </div>
                                                </li>

                                                <li class="newItem">
                                                    <div class="wrap clearfix">
                                                        <a href="/blogs/news/cach-phoi-hoa-tiet-ke-mua-he-an-tuong-nhu-sao-ngoai">
                                                            <img src="https://file.hstatic.net/1000244873/article/blog1_c22673e0c0334f00b45e6aa180dfe42f_large.jpg" alt="Cách phối họa tiết kẻ mùa hè ấn tượng như sao ngoại">
                                                        </a>
                                                        <div class="lat_news_right_con">
                                                            <h3><a href="/blogs/news/cach-phoi-hoa-tiet-ke-mua-he-an-tuong-nhu-sao-ngoai">Cách phối họa tiết kẻ...</a></h3>
                                                            <h4>23/11/2017</h4>
                                                        </div>
                                                    </div>
                                                </li>

                                                <li class="newItem">
                                                    <div class="wrap clearfix">
                                                        <a href="/blogs/news/phoi-quan-jeans-cap-cao-theo-phong-cach-thap-nien-1970">
                                                            <img src="https://file.hstatic.net/1000244873/article/blog2_large.jpg" alt="Phối quần jeans cạp cao theo phong cách thập niên 1970">
                                                        </a>
                                                        <div class="lat_news_right_con">
                                                            <h3><a href="/blogs/news/phoi-quan-jeans-cap-cao-theo-phong-cach-thap-nien-1970">Phối quần jeans cạp cao...</a></h3>
                                                            <h4>23/11/2017</h4>
                                                        </div>
                                                    </div>
                                                </li>



                                            </ul>
                                        </div>
                                    </div>


                                    <div class="sing_right_widget">
                                        <h2>Tags</h2>
                                        <div class="sing_right_widg_content">
                                            <ul class="category_right blogTags">




                                                <li>
                                                    <a href="https://st-fashion.myharavan.com/blogs/news/tagged/thoi-trang">Thời trang</a>
                                                </li>





                                                <li>
                                                    <a href="https://st-fashion.myharavan.com/blogs/news/tagged/tin-hot">Tin hot</a>
                                                </li>





                                                <li>
                                                    <a href="https://st-fashion.myharavan.com/blogs/news/tagged/xem-nhieu">Xem nhiều</a>
                                                </li>





                                                <li>
                                                    <a href="https://st-fashion.myharavan.com/blogs/news/tagged/moi">Mới</a>
                                                </li>



                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </aside>
                        <style>
                            #insBlogSidebar .all_right_widgets {
                                margin-top: 30px;
                            }
                            #insBlogSidebar .all_right_widgets .sing_right_widget {
                                background: #fff;
                                padding: 0px 10px;
                            }
                            .sing_right_widget ul {
                                margin: 0;
                                padding: 0;
                                list-style: none;
                            }
                            #insBlogSidebar .sing_right_widget > h2 {
                                padding: 10px 5px;
                                border-bottom: 1px solid transparent;
                                border-top-left-radius: 3px;
                                border-top-right-radius: 3px;
                                font-size: 15px;
                                text-transform: uppercase;
                            }
                            .lat_news_right .newItem {
                                margin-bottom: 15px;
                                border-bottom: 1px dashed #eaeaea;
                            }
                            .lat_news_right .newItem:last-child {
                                margin-bottom: 15px;
                                border-bottom: 0;
                            }
                            .lat_news_right .newItem .lat_news_right_con {
                                padding: 10px 0;
                            }
                            .lat_news_right .newItem h3 {
                                font-size: 15px;
                                display: block;
                                margin: 0;
                                line-height: 1.3;
                                margin-bottom: 5px;
                            }
                            .lat_news_right .newItem time {
                                font-size: 13px;
                                font-style: italic;
                                color: #999;
                            }
                            ul.category_right.blogTags li {
                                display: inline-block;
                                margin: 0px 5px 10px 0px;
                            }
                            ul.category_right.blogTags li a {
                                display: inline-block;
                                background: #e2e2e2;
                                color: #333;
                                padding: 4px 9px;
                                position: relative;
                                margin: 5px;
                                font-size: 12px;
                                border-left: 3px solid #eb0088;
                            }
                            ul.category_right.blogTags li a:before {
                                left: 0;
                                top: 8px;
                                border: solid transparent;
                                content: " ";
                                height: 0;
                                width: 0;
                                position: absolute;
                                pointer-events: none;
                                border-color: rgba(136, 183, 213, 0);
                                border-left-color: #eb0088;
                                border-width: 4px;
                            }
                        </style>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
