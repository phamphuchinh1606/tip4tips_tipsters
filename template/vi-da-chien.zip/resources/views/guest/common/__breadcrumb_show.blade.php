<div class="insBreadcrumb " >
    <div class="container">
        <div class="breadcrumb-wrap">
            <ol class="breadcrumb breadcrumb-arrow hidden-sm hidden-xs">
                <li><a href="/" target="_self">Trang chủ</a></li>
                <!--li><a href="/collections" target="_self">Danh mục</a></li-->
                <li><a href="/collections/so-mi-nam" target="_self">Sơ Mi Nam</a></li>
                <li class="active"><span> Áo sơ mi dài tay Aristino ALS021</span></li>
            </ol>
        </div>
    </div>
</div>