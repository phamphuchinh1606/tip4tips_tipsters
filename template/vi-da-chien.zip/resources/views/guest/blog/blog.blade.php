@extends('guest.layouts.master')

@section('head.title','Ví Da Khắc Tên')

@section('body.content')

@endsection