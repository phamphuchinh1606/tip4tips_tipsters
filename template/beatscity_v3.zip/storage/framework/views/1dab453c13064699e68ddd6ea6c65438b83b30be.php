<?php
use App\Common\Common;
use App\Common\Utils;
//use App\Model\Role;
use \Carbon\Carbon;
use \App\User;
$auth = Auth::user();
?>
<header class="main-header">

    <!-- Logo -->
    <a href="/" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>A</b>BCY</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg">BeatsCity</span>
    </a>

    <!-- Header Navbar -->
    <!-- Right Side Of Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                <?php else: ?>
                <!-- Messages: style can be found in dropdown.less-->
                
                    
                    
                        
                        
                    
                    
                        
                            
                            

                            
                            
                        
                        
                    
                
                <!-- /.messages-menu -->

                <!-- User Account Menu -->
                <li class="dropdown user user-menu">
                    <!-- Menu Toggle Button -->
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <!-- The user image in the navbar-->
                        <img src="<?php if($auth->image_profile): ?><?php echo e($auth->image_profile); ?><?php else: ?><?php echo e(asset(Utils::$PATH__DEFAULT__AVATAR)); ?><?php endif; ?>" class="user-image" alt="<?php echo e($auth->username); ?>">
                        
                        <!-- hidden-xs hides the username on small devices so only the image appears. -->
                        <span class="hidden-xs"><?php echo e($auth->username); ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- The user image in the menu -->
                        <li class="user-header">
                            <img src="<?php if($auth->image_profile): ?><?php echo e($auth->image_profile); ?><?php else: ?><?php echo e(asset(Utils::$PATH__DEFAULT__AVATAR)); ?><?php endif; ?>" class="img-circle" alt="User Image">
                            
                            <p>
                                <?php if($auth->fullname): ?> <?php echo e($auth->fullname); ?> <?php else: ?> <?php echo e($auth->username); ?> <?php endif; ?>
                                <small>Member since <?php echo e(Carbon::parse($auth->create_at)->format('F. Y')); ?></small>
                            </p>
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-left">
                                
                                <a href="" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    Sign out
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>
