<?php use App\Common\Utils; ?>

<?php $__env->startSection('title', 'Edit Event'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/intlTelInput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('js/admin/intlTelInput.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            var date_input=$('input.date'); //our date input has the name "date"
            var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            });

            $("#phone").intlTelInput({
                allowDropdown: false,
                localizedCountries: {'de': 'Deutschland' },
                preferredCountries: ['vn', 'jp'],
                separateDialCode: true,
                utilsScript: "<?php echo e(asset('js/admin/utils.js')); ?>"
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form role="form" method="post" action="<?php echo e(route('event.edit',['id'=>$event->id])); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-md-8">
                <!-- create manager form -->
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                        <a href="<?php echo e(route('event.index')); ?>" class="btn btn-xs btn-default pull-right"><i class="fa fa-angle-left"></i> Back to list</a>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-xs-6">
                                <!-- text input -->
                                <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                                    <label>Title</label>
                                    <input name="title" value="<?php echo e($event->title); ?>" type="text" class="form-control" placeholder="Enter ..." required>
                                    <?php if($errors->has('title')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('title')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <!-- text input -->
                                <div class="form-group<?php echo e($errors->has('sub_title') ? ' has-error' : ''); ?>">
                                    <label>Sub Title</label>
                                    <input name="sub_title" value="<?php echo e($event->sub_title); ?>" type="text" class="form-control" placeholder="Enter ..." required>
                                    <?php if($errors->has('sub_title')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('sub_title')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-xs-6">
                                <!-- text input -->
                                <div class="form-group<?php echo e($errors->has('venue_id') ? ' has-error' : ''); ?>">
                                    <label>Venue</label>
                                    <select name="venue_id" class="form-control" required>
                                        <option value="" disabled selected>Please pick a venue type</option>
                                        <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($venue->id); ?>" <?php if($event->venue_id == $venue->id): ?> selected <?php endif; ?>><?php echo e($venue->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('venue_id')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('venue_id')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="form-group group__gender">
                                    <label style="width: 100%">Status</label>
                                    <div class="radio-inline">
                                        <label>
                                            <input type="radio" value="Public" name="status" <?php if($event->status == 'Public'): ?> checked <?php endif; ?>>
                                            Public
                                        </label>
                                    </div>
                                    <div class="radio-inline">
                                        <label>
                                            <input type="radio" value="Un Public" name="status" <?php if($event->status == 'Un Public'): ?> checked <?php endif; ?>>
                                            Un Public
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <input class="form-control date" name="start_date" value="<?php echo e($event->start_date); ?>"
                                           placeholder="dd/mm/yyyyy" type="text" autocomplete="off" required/>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <input class="form-control date" name="end_date" value="<?php echo e($event->end_date); ?>"
                                           placeholder="dd/mm/yyyyy" type="text" autocomplete="off" required/>
                                </div>
                            </div>
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea name="description" class="form-control" placeholder="Enter..." rows="5"><?php echo e($event->description); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <input id="imgHandleInput" name="image" type="file" value="<?php echo e($event->image); ?>">
                        <a href="<?php echo e(route('event.index')); ?>" class="btn btn-default">Cancel</a>
                        <button type="submit" class="btn btn-primary pull-right">Update</button>
                    </div>
                </div>

                <!-- /.box -->
            </div>
            <div class="col-md-4">
                <!-- Profile Image -->
                <div class="box box-warning">
                    <div class="box-body">
                        <div class="upload__area-image">
                        <span>
                            <img id="imgHandle" src="<?php echo e(asset(Utils::$PATH__IMAGE)); ?>/<?php echo e($event->image); ?>">
                            <label for="imgAnchorInput">Upload image</label>
                        </span>
                            <p><small>(Please upload a file of type: jpeg, png, jpg, gif, svg.)</small></p>
                        </div>
                        <div class="form__upload">
                            <form action="" enctype="multipart/form-data" method="post">
                                <div class="form-inline-simple">
                                    <input type="file" class="'form-control" id="imgAnchorInput" onchange="loadFile(event)">
                                    
                                    
                                </div>
                                <script>
                                    var loadFile = function(event) {
                                        var output = document.getElementById('imgHandle');
                                        output.src = URL.createObjectURL(event.target.files[0]);
                                        document.getElementById('imgHandleInput').files = event.target.files;
                                    };
                                </script>

                            </form>

                        </div>
                    </div>
                </div>
                <!-- /.box -->
            </div>

        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>