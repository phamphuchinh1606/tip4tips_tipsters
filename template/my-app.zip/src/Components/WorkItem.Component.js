import React, { Component } from "react";
import {Link} from 'react-router-dom';
class WorkItemComponent extends Component {
    onDelete  = (id) => {
        this.props.onDelete(id);    
    }
    render() {
    let { work } = this.props;
    return (
        <tr>
        <td>{work.id}</td>
        <td>{work.name}</td>
        <td>{work.plan_id}</td>
        <td>{work.start_Date}</td>
        <td>{work.end_Date}</td>
        <td>
           <Link to ={`work/add/${work.id}`}  className="btn btn-success" style={{ marginRight:"10px" }}>Sửa</Link>
           <button type="button" className="btn btn-danger" onClick={(e) =>this.onDelete(work.id)}>Delete</button>
        </td>
      </tr>
    );
  }
}

export default WorkItemComponent;
