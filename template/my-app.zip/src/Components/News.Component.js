import React, { Component } from "react";
import $ from 'jquery';
class NewsComponent extends Component {
  showNews = () => {
    var parser = new DOMParser();
    
    var result = null;
    result = this.props.news.map((item, index) => {
      console.log($(item.description));
      return (
        <div className="jumbotron" key={index}>
          <div className="container">
            <h3>{item.title}</h3>
            <p>Contents ...</p>
          
              <img
                width={400}
                height={200}
                src={$(item.description).find("img").attr("src")}
              />
            
           
              <a href={item.link} className="btn btn-primary btn-lg">
                Read more
              </a>
            
          </div>
        </div>
      );
    });
    return result;
  };
  render() {
    return <div>{this.showNews()}</div>;
  }
}

export default NewsComponent;
