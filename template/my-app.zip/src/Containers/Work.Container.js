import React, { Component } from 'react';
import{connect} from 'react-redux';
import * as actions from '../Actions/index';
import * as urls from '../API/URL';
import WorkListComponent from '../Components/WorkList.Component';
import callApi from '../API/apiCaller';
class WorkContainer extends Component {

  constructor(props){
    super(props);
  }
  getAllWork = ()=>{
    callApi(urls.GET_ALL_WORK,'GET',null).then(res=>{
        this.props.fetchAllWork(res.data);
    });
  }
  componentDidMount(){
    //console.log('componentDidMount');
    this.getAllWork();

  }
//   onDelete = (id) =>{
//     callApi(urls.GET_DELETE_PLAN.toString() + `?id=${id}` ,'GET',null).then(res=>{
//         this.getAllPlan();
//     });
//   }
  render() {
    let {work} =  this.props;
    return (
      <WorkListComponent works = {work.works} onDelete = {this.onDelete}/>
    );
  }
}

const mapStateToProps = (state) => {
  return{
    work : state.work
  }
}
const mapDispatchToProps = (dispatch,props) => {
    return {
        fetchAllWork:(works) => {
            dispatch(actions.fetchAllWork(works));
        }
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(WorkContainer);
