import React, { Component } from 'react';
import{connect} from 'react-redux';
import * as actions from '../Actions/index';
import * as urls from '../API/URL';
import NewsComponent from '../Components/News.Component';
import callApi from '../API/apiCaller';
class NewsContainer extends Component {

  constructor(props){
    super(props);
  }
  getAllNews(){
    callApi(urls.GET_ALL_NEWS,'GET',null).then((res)=>{
        
      var parser = new DOMParser();
      var lstItemNews = parser.parseFromString(res.data,"text/xml").getElementsByTagName("item");
      var lst = [];
      var a = lstItemNews[1].childNodes[3];
      //var b = parser.parseFromString(a,"text/xml").firstChild.firstChild;
      console.log(res.data);
      for (let i = 0; i < lstItemNews.length; i++) {
       
         let news = {
            title:lstItemNews[i].childNodes[1].childNodes[0].nodeValue,
            description:lstItemNews[i].childNodes[3].childNodes[0].nodeValue,
            link:lstItemNews[i].childNodes[7].childNodes[0].nodeValue
         }
         lst.push(news);
      }
      this.props.fetchAllNews(lst);
    });
  }
  componentDidMount(){
    this.getAllNews();
  }
  render() {
    return (
      <NewsComponent news = {this.props.news}/>
    );
  }
}

const mapStateToProps = (state) => {
  return{
    news:state.news
  }
}
const mapDispatchToProps = (dispatch,props) => {
    return {
      fetchAllNews:(news)=>{
        dispatch(actions.getAllNews(news));
      }
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(NewsContainer);
