import React, { Component } from 'react';
import{connect} from 'react-redux';
import * as actions from '../Actions/index';
import * as urls from '../API/URL';
import callApi from '../API/apiCaller';
import WorkAddComponent from '../Components/WorkAdd.Component';
import {  Redirect  } from "react-router-dom";
class AddWorkContainer extends Component {

  constructor(props){
    super(props);
  }
  componentDidMount(){
      callApi(urls.GET_WORK_BY_ID + `?idWork=${this.props.match.params.id}`,'GET',null).then((res)=>{
          this.props.getWorkById(res.data.result);
      });
      callApi(urls.GET_ALL_WORK_TYPE,'GET',null).then((res)=>{
          this.props.getAllWorkType(res.data);
      });
      callApi(urls.GET_ALL_PLAN,'GET',null).then((res)=>{
        this.props.getAllPlan(res.data);
      });
  }
  addPlan = (plan) => {
    // callApi(urls.POST_ADD_PLAN,'POST',plan).then((res)=>{
    //     this.props.history.goBack();
    // });
    // this.props.resetPlanEditting();
  }
  render() {
    return (
      <WorkAddComponent onAddWork={this.addPlan} workEditting = {this.props.work.workEditting} worksType={this.props.work.workTypes} plans = {this.props.plans}/>
    );
  }
}

const mapStateToProps = (state) => {
  return{
    work:state.work,
    plans:state.plan
  }
}
const mapDispatchToProps = (dispatch,props) => {
    return {
      getWorkById:(work)=>{
        dispatch(actions.getWorkById(work));
      },
      getAllWorkType:(worksType) => {
        dispatch(actions.getAllWorkType(worksType));
      },
      getAllPlan:(plans)=>{
        dispatch(actions.fetchAllPlan(plans));
      }
      
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(AddWorkContainer);
