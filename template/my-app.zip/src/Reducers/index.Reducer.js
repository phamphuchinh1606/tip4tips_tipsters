import{combineReducers} from 'redux';
import product from './product.Reducer';
import plan from './plan.Reducer';
import planEditting from './planEditing.Reducer';
import work from './work.Reducer';
import news from './news.Reducer';
const appReducers = combineReducers({
	product:product,
	plan:plan,
	planEditting:planEditting,
	work:work,
	news:news
});

export default appReducers