import * as types from '../Constant/ActionType';

// import * as api from '../API/Product';

var initialState  = {
    id:0,
    name:'',
    start_Date:'',
    end_Date:''
};

var myReducer = (state = initialState,action) => {
	switch (action.type) {
        case types.GET_PLAN_BY_ID:
            state = action.plan
			return state;
            break;
        case types.RESET_PLAN:
            state = initialState
            return state;
            break;
		default:
			//console.log(api.getAllProduct());
			return state;
			break;
	}
};

export default myReducer