import * as types from '../Constant/ActionType';

// import * as api from '../API/Product';

var initialState  = {
	works:[],
	workTypes:[],
    workEditting:{
        id:0
    }
};


var myReducer = (state = initialState,action) => {
	switch (action.type) {
		case types.FETCH_ALL_WORK:
		   return Object.assign({},state,{works:action.works});
		   break;
		case types.GET_WORK_BY_ID:
			//console.log(action.work);
			return Object.assign({},state,{workEditting:action.work});
			break;
		case types.GET_ALL_WORK_TYPE:
			//console.log(action.worksType);
			return Object.assign({},state,{workTypes:action.worksType});
			break;
		case types.RESET_STATE_WORK:
			return state;
			break;
		default:
			//console.log(api.getAllProduct());
			return state;
			break;
	}
};

export default myReducer