import * as types from '../Constant/ActionType';



export const fetchAllProduct = (products) => {
	return {
		type:types.FETCH_ALL_PRODUCT,
		products:products
	}
}

export const fetchAllPlan = (plans) => {
	return {
		type:types.FETCH_ALL_PLAN,
		plans:plans
	}
}

export const getPlanById = (plan) => {
	return {
		type:types.GET_PLAN_BY_ID,
		plan:plan
	}
}

export const resetPlan = () => {
	return {
		type:types.RESET_PLAN
		
	}
}

export const fetchAllWork = (works) => {
	return {
		type:types.FETCH_ALL_WORK,
		works:works
	}
}

export const getWorkById = (work) => {
	return {
		type:types.GET_WORK_BY_ID,
		work:work
	}
}

export const resetStateWork = () => {
	return {
		type:types.RESET_STATE_WORK
		
	}
}

export const getAllWorkType = (worksType) => {
	return {
		type:types.GET_ALL_WORK_TYPE,
		worksType:worksType
	}
}

export const getAllPlan = (plans) => {
	return {
		type:types.GET_ALL_PLAN,
		plans:plans
	}
}

export const getAllNews = (news) => {
	return {
		type:types.FETCH_ALL_NEWS,
		news:news
	}
}
