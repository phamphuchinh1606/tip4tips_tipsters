import React, { Component } from 'react';
import WorkContainer from '../Containers/Work.Container';

class WorkPage extends Component {
  render() {
    return (
        <WorkContainer/>
      
   
      
   
    );
  }
}

export default WorkPage;
