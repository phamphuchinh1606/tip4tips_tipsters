import React, { Component } from 'react';
import PlanContainer from '../Containers/PlanContainer';

class PlanPage extends Component {
  render() {
    return (
        <PlanContainer/>
      
   
      
   
    );
  }
}

export default PlanPage;
