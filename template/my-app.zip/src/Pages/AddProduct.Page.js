import React, { Component } from 'react';
import AddProductContainer from '../Containers/AddProduct.Container';

class AddProductPage extends Component {
  render() {
    return (
        <AddProductContainer/>
      
   
      
   
    );
  }
}

export default AddProductPage;
