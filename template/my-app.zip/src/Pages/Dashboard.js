import React, { Component } from 'react';


class Dashboard extends Component {
  render() {
    return (
        <h1>Dashboard</h1>
      
   
      
   
    );
  }
}

export default Dashboard;
