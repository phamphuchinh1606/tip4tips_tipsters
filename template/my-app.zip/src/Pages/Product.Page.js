import React, { Component } from 'react';
import ProductContainer from '../Containers/Product.Container';

class ProductPage extends Component {
  render() {
    return (
        <ProductContainer/>
      
   
      
   
    );
  }
}

export default ProductPage;
