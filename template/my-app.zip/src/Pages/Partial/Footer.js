import React, { Component } from 'react';


class Footer extends Component {
  render() {
    return (
      
     
      <div className="dev-page">
        {/* page footer */}   
        {/* dev-page-footer-closed dev-page-footer-fixed */}
        <div className="dev-page-footer dev-page-footer-fixed"> 
          {/* container */}
          <div className="container">
            <div className="copyright">
              <p>© 2016 Baxster . All Rights Reserved . Design by <a href="http://w3layouts.com/">W3layouts</a></p> 
            </div>
            {/* //page footer container */}
          </div>
          {/* //container */}
        </div>
        {/* /page footer */}
      </div>
    
    
    );
  }
}

export default Footer;
