import React, { Component } from 'react';
import AddPlanContainer from '../Containers/AddPlan.Container';

class AddPlanPage extends Component {
  render() {
    return (
        <AddPlanContainer history = {this.props.history} match = {this.props.match}/>
      
   
      
   
    );
  }
}

export default AddPlanPage;
