import React, { Component } from 'react';
import NewsContainer from '../Containers/News.Container';

class NewsPage extends Component {
  render() {
    return (
        <NewsContainer/>
      
   
      
   
    );
  }
}

export default NewsPage;
