<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Common\Common;
use App\Common\Utils;
use App\User;
use App\Model\Role;
use App\Model\RoleType;
use App\Model\Region;

class UsersAPIController extends Controller
{
    /*===========================================================================
      * CONTROLLER FOR API
      * ==========================================================================*/
    public function show($tipsterId){
        $user = User::find($tipsterId);
        $role = Role::find($user->role_id);
        $roletype = RoleType::find($role->roletype_id);
        if(isset($user) && isset($user) && isset($user)){
            $user["level"] = $role->name." - ".$roletype->name;
            $user["showGender"] = $user->showGender($user->gender);
            $region = Region::getNameByID($user->region_id);
            if($region){
                $user["region"] = $region->name;
            }
            $user["lang_text"] = Common::showTextLanguage($user->preferred_lang);
            $user["path_image"] = asset(Utils::$PATH__IMAGE);
        }
        $jsonValue = [
            "userInfo" => $user
        ];
        return response()->json($jsonValue, 201);

    }
}
