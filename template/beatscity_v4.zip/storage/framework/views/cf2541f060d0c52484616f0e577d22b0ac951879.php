<?php ?>

<?php $__env->startSection('title', 'List Event Beat'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $('#viewList').DataTable({
                'paging'      : true,
                'lengthChange': false,
                'searching'   : true,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : true,
                'order': [],
                'columnDefs': [ { orderable: false, targets: [0]}]
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-list">
        <div class="box-header clearfix">
            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            <a href="<?php echo e(route('event_beat.create')); ?>" class="btn btn-md btn-primary pull-right"><i class="fa fa-plus"></i> New Action</a>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success clearfix">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div>
                <br />
            <?php endif; ?>
            <div class="table-responsive">
                <table id="viewList" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>No.</th>
                        <th>Event</th>
                        <th>Action</th>
                        <th>Points</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i= 0; ?>
                    <?php $__currentLoopData = $eventBeats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventBeat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++ ?>
                        <tr>
                            <td width="40" align="center"><?php echo $i?></td>
                            <td>
                                <?php echo e($eventBeat->event_name); ?>

                            </td>
                            <td>
                                <?php echo e($eventBeat->action_name); ?>

                            </td>
                            <td>
                                <?php echo e($eventBeat->points); ?>

                            </td>
                            <td class="actions text-center" style="width: 100px">
                                <a href="" class="btn btn-xs btn-success" title="View"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('event_beat.edit',['id'=>$eventBeat->id])); ?>" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-pencil"></i></a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </table>
            </div>
        </div>
        <!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>