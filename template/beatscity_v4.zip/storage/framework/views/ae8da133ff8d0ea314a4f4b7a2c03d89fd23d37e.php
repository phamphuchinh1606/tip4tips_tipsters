<?php
    use App\Common\BeatsCityCommon;
    use App\Common\Utils;
?>

<?php $__env->startSection('title', 'Events Listing'); ?>



<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/jquery.scrollbar.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/admin/home.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function() {
            $('.event-item').mouseenter(function(){
                $(this).addClass('background-mouse-enter');
                $(this).find('.item-descript1').removeClass('des-detail');
            });
            $('.event-item').mouseleave(function(){
                $(this).removeClass('background-mouse-enter');
                $(this).find('.item-descript1').addClass('des-detail');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="box box-list">
        <div class="row dashboard">
            <div class="box-header clearfix">
                <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <?php $__currentLoopData = $listEvent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-6">
                            <div class="col-xs-12 event-item well">
                                <div class="date-content">
                                    <div class="big-calendar-icon">
                                        <div class="day">
                                            <?php echo e(BeatsCityCommon::getDayOnDate($eventItem->created_at)); ?>

                                        </div>
                                        <div class="month">
                                            <?php echo e(BeatsCityCommon::getMonthOnDate($eventItem->created_at)); ?>

                                        </div>

                                    </div>
                                    <span style="font-size: 11px;clear: both; margin-top: 5px;color: #080808; white-space: nowrap; display: block; margin-top: 5px;">
                                    <?php echo e(BeatsCityCommon::dateFormat($eventItem->created_at,'h:i')); ?>

                                </span>
                                </div>
                                <div class="image-content">
                                    <div class="img-wrap">
                                        <a title="<?php echo e($eventItem->title); ?>"
                                           href="#">
                                            <img class="item-thumb1"
                                                 src="<?php echo e(asset(Utils::$PATH__IMAGE)); ?>/<?php echo e($eventItem->image); ?>"
                                                 alt="<?php echo e($eventItem->title); ?>">
                                        </a>
                                    </div>
                                    <div class="industry-line">
                                        Venue: <a title="Tourism / Hospitality / Entertainment / Travel" class="vtip greyout"
                                                  href="#"><?php echo e($eventItem->venue_name); ?></a>
                                    </div>
                                    <div class="type-line">
                                        Venue Type: <a title="Exhibitions" class="vtip greyout"
                                                       href="#"><?php echo e($eventItem->venue_type_name); ?></a>
                                    </div>
                                </div>
                                <div class="des-content">
                                    <h4>
                                        <a class="item-title1"
                                           href="#"
                                           title="<?php echo e($eventItem->title); ?>">
                                            <?php echo e($eventItem->title); ?> </a>
                                    </h4>
                                    <p class="item-descript1 des-detail">
                                        <?php echo e($eventItem->description_text); ?>

                                    </p>
                                    <p class="des-place">
                                        <a class="blue" href="#"
                                           title="<?php echo e($eventItem->sub_title); ?>">
                                            <?php echo e($eventItem->sub_title); ?> </a>
                                    </p>
                                </div>
                                <div class="gobtn share-content">
                                    <?php $__currentLoopData = $eventItem->actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($action['action_name'] == \App\Common\Utils::$ACTION_NAME_IM_GOING): ?>
                                            <a rev="" class="sharebtn button-silver-style green-check btn" href="javascript:void(0)"
                                               rel="international-travel-expo-ho-chi-minh-city-2018-september-6th-2018">
                                                I'm going
                                            </a>
                                        <?php endif; ?>
                                        <?php if($action['action_name'] == \App\Common\Utils::$ACTION_NAME_POST_VIDEO_INSTAGRAM): ?>
                                            <a rev="" class="sharebtn button-silver-style green-check btn" href="javascript:void(0)"
                                               rel="international-travel-expo-ho-chi-minh-city-2018-september-6th-2018">
                                                Post video Instagram
                                            </a>
                                        <?php endif; ?>
                                        <?php if($action['action_name'] == \App\Common\Utils::$ACTION_NAME_POST_VIDEO_BEATS_CITY): ?>
                                            <a rev="" class="sharebtn button-silver-style green-check btn" href="javascript:void(0)"
                                               rel="international-travel-expo-ho-chi-minh-city-2018-september-6th-2018">
                                                Post video Beats City
                                            </a>
                                        <?php endif; ?>
                                        <?php if($action['action_name'] == \App\Common\Utils::$ACTION_NAME_SHARE_INSTAGRAM): ?>
                                            <a class="fb-share-btn button-silver-style share-button btn" href="javascript:void(0)"
                                               rel="1">
                                                <i class="fa fa-instagram pull-left pull-left"></i>Share
                                            </a>
                                        <?php endif; ?>
                                        <?php if($action['action_name'] == \App\Common\Utils::$ACTION_NAME_SHARE_FB): ?>
                                            <a class="fb-share-btn button-silver-style share-button btn" href="javascript:void(0)"
                                               rel="1">
                                                <i class="fa fa-facebook-square pull-left"></i>Share
                                            </a>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>