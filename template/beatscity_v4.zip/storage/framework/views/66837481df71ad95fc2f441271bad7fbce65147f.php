<?php
use App\Common\Common;
use App\Common\Utils;
$auth = Auth::user();
//$authInfo = Common::userInfo($auth->id);
?>
<aside class="main-sidebar">
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img <?php if($auth->image_profile): ?> src="<?php echo e($auth->image_profile); ?>" <?php else: ?> src="<?php echo e(asset(Utils::$PATH__DEFAULT__AVATAR)); ?>" <?php endif; ?> class="img-circle" alt="<?php echo e($auth->username); ?> Avatar">
                
            </div>
            <div class="pull-left info">
                <p><?php if($auth->fullname): ?> <?php echo e($auth->fullname); ?> <?php else: ?> <?php echo e($auth->username); ?> <?php endif; ?></p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form (Optional) -->
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
          <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
          </button>
        </span>
            </div>
        </form>
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo e((Request::is('*dashboard*') || Request::is('/') ? 'active' : '')); ?>">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <i class="fa fa-home"></i><span>HOME</span>
                </a>
            </li>
            <li class="<?php echo e((Request::is('*venue-type*') ? 'active' : '')); ?>">
                <a href="<?php echo e(route('venue_type.index')); ?>"><i class="fa fa-street-view"></i><span>Venue Type</span></a>
            </li>
            <li class="<?php echo e((Request::is('*venues*') ? 'active' : '')); ?>">
                <a href="<?php echo e(route('venue.index')); ?>"><i class="fa fa-eye"></i><span>Venues</span></a>
            </li>
            <li class="<?php echo e((Request::is('*events*') ? 'active' : '')); ?>">
                <a href='<?php echo e(route('event.index')); ?>'><i class="fa fa-users"></i><span>Events</span></a>
            </li>
            
            <li class="<?php echo e((Request::is('*actions*') ? 'active' : '')); ?>">
                <a href="<?php echo e(route('action.index')); ?>"><i class="fa fa-shield"></i><span>Actions</span></a>
            </li>
            <li class="<?php echo e((Request::is('*event-beat*') ? 'active' : '')); ?>">
                <a href="<?php echo e(route('event_beat.index')); ?>"><i class="fa fa-calendar" aria-hidden="true"></i><span>Event Beats</span></a>
            </li>


        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
