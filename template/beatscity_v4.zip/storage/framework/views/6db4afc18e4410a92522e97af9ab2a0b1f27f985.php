<?php $__env->startSection('title', 'Edit Event Beat'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            <a href="<?php echo e(route('event_beat.index')); ?>" class="btn btn-xs btn-default pull-right"><i class="fa fa-angle-left"></i> Back to list</a>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6 col-sm-push-3">
                    <form role="form" method="post" action="<?php echo e(route('event_beat.edit',['id' => $eventBeat->id])); ?>" enctype = "multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php if(count($errors) > 0): ?>
                                    <strong>Whoops!</strong> There were some problems with your input.
                                <?php endif; ?>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div><br />
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                        <div class="form-group<?php echo e($errors->has('event_id') ? ' has-error' : ''); ?>">
                            <label>Event</label>
                            <select name="event_id" class="form-control" required>
                                <option value="" disabled selected>Please pick a event</option>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($event->id); ?>" <?php if($eventBeat->event_id == $event->id): ?> selected <?php endif; ?>><?php echo e($event->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('event_id')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('event_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('action_id') ? ' has-error' : ''); ?>">
                            <label>Action</label>
                            <select name="action_id" class="form-control" required>
                                <option value="" disabled selected>Please pick a action</option>
                                <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($action->id); ?>" <?php if($eventBeat->action_id == $action->id): ?> selected <?php endif; ?>><?php echo e($action->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('action_id')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('action_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('points') ? ' has-error' : ''); ?>">
                            <label>Point</label>
                            <input name="points" type="number" class="form-control" value="<?php echo e($eventBeat->points); ?>" required autofocus style="width: 100px;" min="0" placeholder="Enter ...">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('points')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('comments') ? ' has-error' : ''); ?>">
                            <label>Comments</label>
                            <textarea name="comments" class="form-control" placeholder="Enter..." rows="5"><?php echo e($eventBeat->comments); ?></textarea>
                        </div>

                        <div class="form-action">
                            <a href="<?php echo e(route('event_beat.index')); ?>" class="btn btn-default">Cancel</a>
                            <button type="submit" class="btn btn-primary pull-right">Update</button>
                        </div>
                        <!-- /.box-body -->
                    </form>
                </div>
            </div>
        </div>
        <!-- /.col -->

    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>