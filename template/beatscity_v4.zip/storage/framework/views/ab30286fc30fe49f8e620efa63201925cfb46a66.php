<?php
use App\Common\Common;
use App\Common\Utils;
?>

<?php $__env->startSection('title', 'Venue detail'); ?>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-md-push-8">
            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <div class="upload__area-image">
                        <span><img id="imgHandle" src="<?php if($venue->image): ?><?php echo e(asset(Utils::$PATH__IMAGE)); ?>/<?php echo e($venue->image); ?><?php endif; ?>"></span>
                    </div>
                    <p class="text-muted text-center" title="<?php echo e($venue->name); ?>">
                        <strong><i class="fa fa-user margin-r-5"></i> Image</strong>
                    </p>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-8 col-md-pull-4">
            <!-- About Me Box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                    <span class="group__action pull-right">
                        <a href="<?php echo e(route('venue.index')); ?>" class="btn btn-xs btn-default"><i class="fa fa-angle-left"></i> Back to list</a>
                        <a href="<?php echo e(route('venue.edit', $venue->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-pencil"></i> Edit</a>
                        <a data-toggle="modal" data-target="#popup-confirm" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</a>
                    </span>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-address-book margin-r-5"></i> Full Name
                                <span class="text-highlight"><?php echo e($venue->name); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-building margin-r-5"></i> Venue Type
                                <span class="text-highlight"><?php echo e($venue->venue_type_name); ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="row box-line">
                        <div class="col-sm-6">

                            <p class="text-muted">
                                <i class="fa fa-map-marker margin-r-5"></i> Address
                                <span class="text-highlight"><?php echo e($venue->address); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-address-card margin-r-5"></i> Ward
                                <span class="text-highlight"><?php echo e($venue->ward); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-address-card-o margin-r-5"></i> District
                                <span class="text-highlight"><?php echo e($venue->district); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-eercast margin-r-5"></i> City
                                <span class="text-highlight"><?php echo e($venue->city); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-globe margin-r-5"></i> Longitude
                                <span class="text-highlight"><?php echo e($venue->long); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-clock-o margin-r-5"></i> Latitude
                                <span class="text-highlight"><?php echo e($venue->lat); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    
    <?php echo $__env->make('inc.popup-confirm-delete',['id' => $venue->id, 'name' => $venue->name,'route_delete' => 'venue.delete'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>