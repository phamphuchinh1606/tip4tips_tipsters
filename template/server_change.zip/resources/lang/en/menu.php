<?php

return [
    'product' => 'List of Products',
    'product.create' => 'Add Products',

];
