<?php

namespace App\Http\Controllers\Api;

use App\Model\Lead;
use App\Model\LeadProcess;
use App\Model\Region;
use App\Model\Product;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Common\Common;

class LeadsAPIController extends Controller
{
    /*===========================================================================
      * CONTROLLER FOR API
      * ==========================================================================*/
    public function index(){
        $leads = Lead::getAllLead();

        return $leads;
    }

    public function leadsByTipster($id){
        $leads = Lead::leadsByTipster($id);
        foreach ($leads as $lead) {
            $lead->date = Common::dateFormat($lead->created_at, 'd F Y');
            $lead->status_text = Common::showNameStatus($lead->status);
        }
        return $leads;
    }

    public function add($tipsterId){
        $regions = Region::all();
        $products = Product::getAllProduct();
        $tipsters = User::getUserByID($tipsterId);
        $jsonValue = [
            "regions" => $regions,
            "products" => $products,
            "tipsters" => $tipsters
        ];
        return response()->json($jsonValue, 201);
    }

    public function edit($tipsterId, $leadId){
        $regions = Region::all();
        $products = Product::getAllProduct();
        $tipsters = User::getUserByID($tipsterId);
        $lead = Lead::getLeadByID($leadId);
        $jsonValue = [
            "regions" => $regions,
            "products" => $products,
            "tipsters" => [$tipsters],
            "lead" => $lead
        ];
        return response()->json($jsonValue, 201);
    }

    public function show($id){
        $lead = Lead::getLeadByID($id);
        $historys = LeadProcess::getStatusByLead($id);
        foreach ($historys as $historyItem) {
            $historyItem->status_name = Common::showNameStatus($historyItem->status_id);
            $historyItem->date = Common::dateFormat($historyItem->created_at, 'd-M-Y H:i');
        }
        $lead->historys = $historys;
        return $lead;
    }

    public function store(Request $request)
    {
        $this->validate(request(),[
            'Leadname' => 'required|unique:Leads',
            'password' => 'required|string|min:6|confirmed',
            'fullname' => 'required',
            'email' => 'required|string|email|max:255|unique:Leads',
            'birthday' => 'required|date',
            'phone' => 'required',
            'region' => 'required',
            'avatar' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);
        $lead = Lead::create($request->all());

        return response()->json($lead, 201);
    }

    public function update(Request $request, Lead $lead)
    {
        $this->validate($request,[
            'fullname' => 'required',
            'product' => 'required',
            'region' => 'required',
            'tipster' => 'required'
        ]);
        $lead->update($request->all());

        return response()->json($lead, 200);
    }

    public function delete(Lead $lead)
    {
        $lead->delete();

        return response()->json(null, 204);
    }
}
