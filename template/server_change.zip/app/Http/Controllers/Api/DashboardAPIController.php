<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Common\Common;
use App\Common\Utils;
use App\Model\Lead;
use App\Model\Product;
use Log;
use Validator;

class DashboardAPIController extends Controller
{
    /*===========================================================================
      * CONTROLLER FOR API
      * ==========================================================================*/

    public function dashboard($tipsterId)
    {
        $recentleads = Lead::getRecentLeadsByTipster($tipsterId,5);
        foreach ($recentleads as $recentlead){
            $recentlead->created_date = Common::dateFormat($recentlead->created_at,'d-M-Y');
            $recentlead->status_text = Common::showNameStatus($recentlead->status);
            $recentlead->status_color = Common::colorStatus($recentlead->status);
            $recentlead->product = Product::getProductByID($recentlead->product_id)->name;
        }

        $statusByRecentTipster = Lead::sumStatusByTipsterRecentLead($tipsterId,5);

        $new = 0;
        $colorNew = Common::colorStatus(0);
        $call =0;
        $colorCall = Common::colorStatus(1);
        $quote = 0;
        $colorQuote = Common::colorStatus(2);
        $win = 0;
        $colorWin = Common::colorStatus(3);
        $lost = 0;
        $colorLost = Common::colorStatus(4);
        foreach($statusByRecentTipster as $sumStatus){
            switch ($sumStatus->status) {
                case 0:
                    $new = $sumStatus->countStatus;
                    break;
                case 1:
                    $call = $sumStatus->countStatus;
                    break;
                case 2:
                    $quote = $sumStatus->countStatus;
                    break;
                case 3:
                    $win = $sumStatus->countStatus;
                    break;
                case 4:
                    $lost = $sumStatus->countStatus;
                    break;
            }
        }

        $statusLead = [
        	'new' => $new,
        	'colorNew' => $colorNew,
            'call' => $call,
            'colorCall' => $colorCall,
            'quote' => $quote,
            'colorQuote' => $colorQuote,
            'win' => $win,
            'colorWin' => $colorWin,
            'lost' => $lost,
            'colorLost' => $colorLost
        ];

        $jsonValue = [
        	"recentleads" => $recentleads,
        	"statusByRecentTipster" => $statusByRecentTipster,
        	"statusLead" => $statusLead
        ];

        return response()->json($jsonValue, 201);
    }
    
}
