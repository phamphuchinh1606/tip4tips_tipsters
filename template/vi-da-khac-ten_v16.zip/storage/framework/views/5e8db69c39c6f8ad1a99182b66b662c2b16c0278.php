<?php $__env->startSection('head.title','Danh Sách Tin Tức'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/jquery.dataTables.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/dataTables.bootstrap4.js')); ?>" class="view-script"></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh Sách Tin Tức
                            <div class="card-header-actions">
                                <a class="btn btn-block btn-outline-primary active" href="<?php echo e(route('admin.blog.create')); ?>">
                                    Tạo mới
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                            <tr role="row">
                                                <th>
                                                    STT
                                                </th>
                                                <th>
                                                    Hình ảnh
                                                </th>
                                                <th>
                                                    Tiêu đề
                                                </th>
                                                <th>
                                                    Ngày đăng
                                                </th>
                                                <th>
                                                    Tình trạng
                                                </th>
                                                <th>
                                                    Actions
                                                </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo e($index + 1); ?>

                                                        </td>
                                                        <td>
                                                            <img src="<?php echo e(asset(\App\Common\Constant::$PATH_URL_UPLOAD_IMAGE.$blog->blog_image)); ?>"
                                                                width="100" height="100"/>
                                                        </td>
                                                        <td>
                                                            <?php echo e($blog->blog_title); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($blog->str_post_date); ?>

                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge <?php echo e($blog->public_class); ?>"><?php echo e($blog->public_name); ?></span>
                                                        </td>
                                                        <td class="text-center">
                                                            <a class="btn btn-success" href="#">
                                                                <i class="fa fa-search-plus"></i>
                                                            </a>
                                                            <a class="btn btn-info" href="<?php echo e(route('admin.blog.update',['id' => $blog->id])); ?>">
                                                                <i class="fa fa-edit"></i>
                                                            </a>
                                                            <a class="btn btn-danger" href="#">
                                                                <i class="fa fa-trash-o"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>