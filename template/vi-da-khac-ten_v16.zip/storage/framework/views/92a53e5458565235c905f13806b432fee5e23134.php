<select class="form-control" id="product_type" name="<?php echo e($selectName); ?>">
    <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <optgroup label="<?php echo e($productType->product_type_name); ?>" value="<?php echo e($productType->id); ?>">
            <?php if(isset($productType->childs)): ?>
                <?php $__currentLoopData = $productType->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productTypeChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($productTypeChild->id); ?>" <?php if(isset($defaultValue) && $defaultValue == $productTypeChild->id): ?> selected <?php endif; ?>>
                        <?php echo e($productTypeChild->product_type_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </optgroup>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>