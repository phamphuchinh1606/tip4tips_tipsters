<div id="headerPage">
    <div class="container">
        <div class="insHeaderWrap">
            <div class="row">
                <div id="headerLogo" class="col-md-3 col-sm-12 col-xs-12">
                    <div class="visible-xs visible-sm mbToggle translateY-50">
                        <a href="javascript:void(0)" class="btnMBToggleNav"><img
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAAQlBMVEUAAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEDQTCTWAAAAFnRSTlMA/sJgJXkkeK1jGg/bup9uMeVbWk85sxcycAAAAFxJREFUOMvt1DkSgCAQBdHPpmwCbve/qhFllSA1Gs+LO25EcVs93u1mrkwOYD8dTrVcQWMRPRaNoKeW9mDfWEmSkGihBRvyegyVFGO5hqcaK2AUznRtxEmJGB7dBU9GBJAADKKNAAAAAElFTkSuQmCC"
                                    alt="Beauty style">
                        </a>
                    </div>

                    <p>
                        <a href="/">
                            <img src="https://theme.hstatic.net/1000244873/1000313408/14/logo.png?v=1543"
                                    alt="ST Fashion"/>
                        </a>
                    </p>

                    <h1 class="hide">
                        ST Fashion
                    </h1>

                    <div class="visible-xs visible-sm mbCart translateY-50">
                        <a href="/cart">
                            <div class="icon">
                                <i class="fa fa-shopping-bag" aria-hidden="true"></i>
                            </div>
                            <span id="cartCountMB" class="numberCart cartItemCount " data-count="1">1</span>
                        </a>
                    </div>
                </div>
                <div id="headerSearch" class="col-md-6 col-sm-12 col-xs-12">
                    <div class="frmSearch">
                        <form id="searchFRM" action="/search">
                            <i class="fa fa-search" aria-hidden="true"></i>
                            <input type="hidden" name="type" value="product">
                            <input required="" autocomplete="off" type="text" name="q" id="inputSearchAuto"
                                   placeholder="Tìm kiếm...">
                            <button type="submit" class="insButtonk btnSearch">
                                Tìm kiếm
                            </button>
                        </form>
                        <div id="ajaxSearchResults" class="ajaxSearchAuto" style="display: none">
                            <div class="resultsContent">

                            </div>
                        </div>
                    </div>

                    <ul class="searchEx notStyle">
                        <li class="title"><strong>Gợi ý từ khóa:</strong></li>
                        <li><span>Thời trang nam, thời trang nữ...</span></li>
                    </ul>

                </div>

                <div id="headerUser" class="col-md-3 hidden-sm hidden-xs">
                    <div class="wrap cleafix">
                        <div class="row">

                            <div class="userBox colItem">
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('contact')); ?>">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa fa-globe" aria-hidden="true"></i>
                                            </div>
                                            <div class="text">
                                                <span>Cửa hàng</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>


                            <div class="col-md-4 colItem">
                                <div class="userBox">
                                    <a href="/account">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa fa-user-circle-o" aria-hidden="true"></i>
                                            </div>
                                            <div class="text">

                                                <span>Tài khoản</span>

                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>

                            <div class="col-md-4 colItem">
                                <div class="userBox">
                                    <a href="<?php echo e(route('cart')); ?>">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                                <span class="cartItemCount " data-count="1" id="labelCartCount">
                                                    1
                                                </span>
                                            </div>
                                            <div class="text">
                                                <span>Giỏ hàng</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="overlayMenu"></div>
            </div>
        </div>
    </div>
</div>