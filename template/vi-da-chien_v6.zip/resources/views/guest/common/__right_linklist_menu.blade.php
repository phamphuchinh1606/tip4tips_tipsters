<div class="block left-module linklist">
    <p class="title_block">Danh mục sản phẩm</p>
    <div class="block_content">
        <!-- layered -->
        <div class="layered layered-category">
            <div class="layered-content">
                <ul class="tree-menu notStyle">


                    <li class=" has-child">
                        <span></span>
                        <a class="dropdown-toggle has-category parent " href="/" title="Mẹ và bé" target="_self">
                            <span class="">Ví Nam</span>
                        </a>

                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Đồng hồ" target="_self">
                            Ví Nữ
                        </a>
                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Túi ví" target="_self">
                            Ví 12 Con Giáp
                        </a>
                    </li>



                    <li class=" has-child">
                        <span></span>
                        <a class="dropdown-toggle has-category parent " href="/" title="Thời trang nữ" target="_self">
                            <span class="">Ví Tình Yêu</span>
                        </a>

                    </li>



                    <li class=" has-child">
                        <span></span>
                        <a class="dropdown-toggle has-category parent " href="/" title="Thời trang nam" target="_self">
                            <span class="">Ví Phong Cảnh</span>
                        </a>

                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Mỹ phẩm" target="_self">
                            Ví Cầu An
                        </a>
                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Mắt kính" target="_self">
                            Ví Năm Mới
                        </a>
                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Deal giá sốc" target="_self">
                            Ví Tình Ca
                        </a>
                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Sale tuần" target="_self">
                            Sản Phẩn Hot
                        </a>
                    </li>



                    <li class="">
                        <span></span>
                        <a class="" href="/" title="Trang sức" target="_self">
                            Ví Giá Sốc
                        </a>
                    </li>



                </ul>
            </div>
        </div>
        <!-- ./layered -->
    </div>
</div>