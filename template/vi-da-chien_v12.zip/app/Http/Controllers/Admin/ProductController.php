<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Storage;

class ProductController extends Controller
{
    public function index(){
        $products = $this->productService->getAllLProduct();
        return view('admin.product.index')->with('products',$products);
    }

    public function showCreate(){
        return view('admin.product.create');
    }

    public function store(Request $request){
        $this->productService->createProduct($request);

    }

    public function showUpdate($id){
        $product = $this->productService->getInfoProduct($id);
        return view('admin.product.update',[
            'product' => $product
        ]);
    }

    public function delete($id){
        $this->productService->delete($id);
        return redirect()->route('admin.product.index');
    }


}
