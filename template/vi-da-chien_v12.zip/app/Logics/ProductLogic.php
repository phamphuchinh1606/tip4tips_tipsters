<?php

namespace App\Logics;

use App\Common\Constant;
use App\Models\Product;
use DB;
use App\Models\TableNameDB;

class ProductLogic extends BaseLogic{

    public function getAllLProduct(){
        $listProducts = Db::table(TableNameDB::$TableProduct.' as product')
                            ->join(TableNameDB::$TableProductType.' as type', 'product.product_type_id','=','type.id')
                            ->where('product.is_delete', Constant::$DELETE_FLG_OFF)
                            ->select('product.*', 'type.product_type_name')
                            ->paginate(20);
        return $listProducts;
    }

    public function getProduct($productId){
        return Product::find($productId);
    }

    public function createProduct($params = []){
        if(count($params) > 0){
            $product = new Product();
            $product->product_name = $params['productName'];
            $product->product_code = $params['productCode'];
            $product->vendor_id = $params['vendorId'];
            $product->product_type_id = $params['productTypeId'];
            $product->product_price = $params['productPrice'];
            if(isset($params['productComparePrice']) && $params['productComparePrice'] != null){
                $product->product_compare_price = $params['productComparePrice'];
            }
            $product->product_sale_percent = $params['productSalePercent'];
            $product->is_public = $params['isPublic'];
            $product->product_qty = 0;
            $product->product_description = $params['productDescription'];
            $product->product_content = $params['productContent'];
            $product->save();
            return $product;
        }
        return null;
    }

    public function updateImage(Product $product, $imageName){
        if(isset($product)){
            $product->product_image = $imageName;
            $product->save();
            return $product;
        }
    }

    public function delete($productId){
        $product = Product::find($productId);
        if(isset($product)){
            $product->is_delete = Constant::$DELETE_FLG_ON;
            $product->save();
        }
    }
}
