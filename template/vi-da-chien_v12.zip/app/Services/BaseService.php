<?php

namespace App\Services;

use App\Logics\ProductTypeLogic;
use App\Logics\ProductLogic;
use App\Logics\ProductImageLogic;

class BaseService {
    protected $productTypeLogic;

    protected $productLogic;

    protected $productImageLogic;

    public function __construct(ProductTypeLogic $productTypeLogic, ProductLogic $productLogic, ProductImageLogic $productImageLogic)
    {
        $this->productTypeLogic = $productTypeLogic;
        $this->productLogic = $productLogic;
        $this->productImageLogic = $productImageLogic;
    }
}
