<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/jquery.dataTables.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/dataTables.bootstrap4.js')); ?>" class="view-script"></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh Mục Sản Phẩm
                            <div class="card-header-actions">
                                <a class="btn btn-block btn-outline-primary active" href="<?php echo e(route('admin.product_type.create')); ?>">
                                    Tạo mới
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                                <tr role="row">
                                                    <th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Username: activate to sort column descending" style="width: 391px;">
                                                        Số Thứ Tự
                                                    </th>
                                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Date registered: activate to sort column ascending" style="width: 328px;">
                                                        Tên Danh Mục
                                                    </th>
                                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Role: activate to sort column ascending" style="width: 154px;">
                                                        Tình Trạng
                                                    </th>
                                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Actions: activate to sort column ascending" style="width: 337px;">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $listProductType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr role="row" class="odd">
                                                        <td class="sorting_1">
                                                            <?php echo e($index + 1); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($productType->product_type_name); ?>

                                                        </td>
                                                        <td>
                                                            <span class="badge <?php echo e($productType->public_class); ?>"><?php echo e($productType->public_name); ?></span>
                                                        </td>
                                                        <td>
                                                            <a class="btn btn-success" href="#">
                                                                <i class="fa fa-search-plus"></i>
                                                            </a>
                                                            <a class="btn btn-info" href="<?php echo e(route('admin.product_type.update',['id' => $productType->id])); ?>">
                                                                <i class="fa fa-edit"></i>
                                                            </a>
                                                            <a class="btn btn-danger" href="#">
                                                                <i class="fa fa-trash-o"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>