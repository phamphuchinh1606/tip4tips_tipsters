<?php use App\Common\Constant; ?>



<?php $__env->startSection('head.title','Danh sách sản phẩm'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/quill.snow.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/plugins/dropzone.css')); ?>">
    <link href="<?php echo e(asset('css/admin/dropzon_custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    <script src="<?php echo e(asset('js/admin/plugins/quill.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/admin/plugins/text-editor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/plugins/dropzone.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dropzone-config.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="row">
                        <div class="col-md-8">
                            <form method="post" action="<?php echo e(route('admin.product.create')); ?>" enctype="multipart/form-data" id="form">
                                <?php echo csrf_field(); ?>
                                <div class="card">
                                    <div class="card-header">
                                        <i class="icon-note"></i> Tạo Mới Sản Phẩm
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Tên Sản Phẩm</label>
                                            <div class="col-md-10">
                                                <input class="form-control" id="text-input" type="text" name="product_name" placeholder="Tên sản phẩm"
                                                    value="<?php echo e($product->product_name); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Mã Sản Phẩm</label>
                                            <div class="col-md-10">
                                                <input class="form-control" id="text-input" type="text" name="product_code" placeholder="Mã sản phẩm"
                                                       value="<?php echo e($product->product_code); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Thương hiệu</label>
                                            <div class="col-md-10">
                                                <select class="form-control" id="vendor" name="vendor">
                                                    <option value="0">Please select</option>
                                                    <option value="1">Thương hiệu nổi tiếng</option>
                                                    <option value="2">Thương hiệu cao cấp</option>
                                                    <option value="3">Thương hiệu có sẵn</option>
                                                </select>


                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Loại Sản Phẩm</label>
                                            <div class="col-md-10">
                                                <?php echo $__env->make('admin.common.__select_product_type',['selectName' => 'product_type'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Giá sản phẩm</label>
                                            <div class="col-md-10">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text">Giá Bán</span>
                                                            </div>
                                                            <input class="form-control text-right number" id="product_price" type="text" name="product_price">
                                                            <div class="input-group-append">
                                                                <span class="input-group-text">VNĐ</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text">Giá Gốc</span>
                                                            </div>
                                                            <input class="form-control text-right number" id="product_cost_price" type="text" name="product_cost_price">
                                                            <div class="input-group-append">
                                                                <span class="input-group-text">VNĐ</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text">Tiền Giảm</span>
                                                            </div>
                                                            <input class="form-control text-right number" id="product_compare_price" type="text" name="product_compare_price" disabled>
                                                            <div class="input-group-append">
                                                                <span class="input-group-text">VNĐ</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row pt-3">
                                                    <div class="col-md-4"></div>
                                                    <div class="col-md-4"></div>
                                                    <div class="col-md-4">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text">Phần Trăm</span>
                                                            </div>
                                                            <select class="form-control" id="product_sale_percent" name="product_sale_percent">
                                                                <option value="0">Chọn phần trăm</option>
                                                                <option value="5">5%</option>
                                                                <option value="5">10%</option>
                                                                <option value="5">15%</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Công khai sản phẩm</label>
                                            <div class="col-md-10">
                                                <label class="switch switch-label switch-outline-primary-alt">
                                                    <input class="switch-input" type="checkbox" checked="" name="is_public">
                                                    <span class="switch-slider" data-checked="On" data-unchecked="Off"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Mô tả ngắn sản phẩm</label>
                                            <div class="col-md-10">
                                                <textarea class="form-control" name="product_description" rows="9" placeholder="Nhập mô tả ngắn thông tin sản phẩm"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Nội dung sản phẩm</label>
                                            <div class="col-md-10">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <input type="hidden" value="phamphuchinh" class="editor" name="product_content"/>
                                                        <div id="editor" class="ql-container ql-snow editor_quill product_content">

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-none">
                                            <input type="file" class="'form-control" id="product_main_image" name="product_main_image"/>
                                            <div class="root_product_images">
                                                <input type="hidden" class="'form-control product_images" name="product_images[]" value=""/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-sm btn-primary" type="submit">
                                            <i class="fa fa-dot-circle-o"></i> Submit</button>
                                        <button class="btn btn-sm btn-danger" type="reset">
                                            <i class="fa fa-ban"></i> Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <i class="fa fa-align-justify"></i> Hình Ảnh Chính
                                    <small>slides only</small>
                                </div>
                                <div class="card-body">
                                    <div class="box box-warning">
                                        <div class="box-body">
                                            <div class="upload__area-image">
                                                <span>
                                                    <img id="imgHandle" src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>">
                                                    <label for="imgAnchorInput">Upload image</label>
                                                </span>
                                                <p><small>(Please upload a file of type: jpeg, png, jpg, gif, svg.)</small></p>
                                            </div>
                                            <div class="form__upload">

                                                <div class="form-inline-simple">
                                                    <input type="file" class="'form-control" id="imgAnchorInput" onchange="loadFile(event)">
                                                </div>
                                                <script>
                                                    var loadFile = function(event) {
                                                        var output = document.getElementById('imgHandle');
                                                        output.src = URL.createObjectURL(event.target.files[0]);
                                                        document.getElementById('product_main_image').files = event.target.files;
                                                    };
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <i class="fa fa-align-justify"></i> Danh sách hình ảnh phụ
                                    <small>slides only</small>
                                </div>
                                <div class="card-body">
                                    <div class="carousel slide" id="carouselExampleSlidesOnly" data-ride="carousel">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <form method="post" action="<?php echo e(route('admin.common.upload_image')); ?>"
                                                      enctype="multipart/form-data" class="dropzone" id="my-dropzone">
                                                    <?php echo e(csrf_field()); ?>

                                                    <div class="dz-message">
                                                        <div class="col-xs-8">
                                                            <div class="message">
                                                                <p>Kéo thả file image hoặc click để upload</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="fallback">
                                                        <input type="file" name="file">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        
                                        <div id="preview" style="display: none;">

                                            <div class="dz-preview dz-file-preview">
                                                <div class="dz-image"><img data-dz-thumbnail /></div>

                                                <div class="dz-details">
                                                    <div class="dz-size"><span data-dz-size></span></div>
                                                    <div class="dz-filename"><span data-dz-name></span></div>
                                                </div>
                                                <div class="dz-progress"><span class="dz-upload" data-dz-uploadprogress></span></div>
                                                <div class="dz-error-message"><span data-dz-errormessage></span></div>
                                                <div class="dz-success-mark">

                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    

                                                </div>
                                                <div class="dz-error-mark">

                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>