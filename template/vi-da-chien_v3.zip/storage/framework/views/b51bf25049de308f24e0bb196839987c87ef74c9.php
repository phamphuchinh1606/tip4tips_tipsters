<nav id="headerMenu">
    <div class="container">
        <div id="headerNav" class="">
            <nav id="navWrap" class="nav navSiteMain">
                <div class="loginMB visible-xs visible-sm">
                    <div class="wrapLogin clearfix">
                        <div class="icon">
                            <img src="https://theme.hstatic.net/1000204910/1000273076/14/icon_avatar.png?v=395"
                                 alt=" ">
                        </div>
                        <div class="user">

                            <a class="log-only" href="/account/login" title="Đăng nhập">Đăng nhập</a>
                            <h3>
                                Thông tin tài khoản
                            </h3>

                        </div>
                    </div>
                </div>
                <ul class="nav-navbar notStyle clearfix">


                    <li class="<?php echo e((Request::is('*venue-type*') ? 'active' : '')); ?>">
                        <a href="/" class="" title="Trang chủ">
                            <span>Trang chủ</span>
                        </a>
                    </li>


                    <li class="liChild <?php echo e((Request::is('*collection*') ? 'active' : '')); ?>">
                        <a href="<?php echo e(route('collection')); ?>" title="Sản phẩm" class="">
                            <span>Sản phẩm</span> <i class="fa fa-angle-down" aria-hidden="true"></i>
                        </a>
                        <ul class="mainChild levlup_2" role="menu">


                            <li class=" liChild active">
                                <a href="/" class=""
                                   title="Sản phẩm khuyến mãi"><span>Sản phẩm khuyến mãi</span> <i
                                            class="fa fa-angle-right" aria-hidden="true"></i></a>
                                <ul class="mainChild levlup_3">

                                    <li class="active">
                                        <a href="/" title="Sản phẩm tốt nhất"><span>Sản phẩm tốt nhất</span></a>
                                    </li>

                                    <li class="active">
                                        <a href="/" title="Sản phẩm hay"><span>Sản phẩm hay</span></a>
                                    </li>

                                    <li class="active">
                                        <a href="/" title="Sản phẩm đẹp"><span>Sản phẩm đẹp</span></a>
                                    </li>

                                </ul>
                            </li>


                            <li class="active">
                                <a href="/" title="Sản phẩm hót"><span>Sản phẩm hót</span></a>
                            </li>


                            <li class="active">
                                <a href="/" title="Sản phẩm thông minh"><span>Sản phẩm thông minh</span></a>
                            </li>


                            <li class="active">
                                <a href="/" title="tôi yêu sản phẩm"><span>tôi yêu sản phẩm</span></a>
                            </li>


                        </ul>
                    </li>


                    <li class="">
                        <a href="/collections/thoi-trang" class="" title="Hot deal">
                            <span>Hot deal</span>
                        </a>
                    </li>


                    <li class="<?php echo e((Request::is('*blog*') ? 'active' : '')); ?>">
                        <a href="<?php echo e(route('blog')); ?>" class="" title="Tin tức">
                            <span>Tin tức</span>
                        </a>
                    </li>


                    <li class="">
                        <a href="/pages/about-us" class="" title="Giới thiệu">
                            <span>Giới thiệu</span>
                        </a>
                    </li>


                    <li class="">
                        <a href="/pages/" class="" title="Hướng dẫn">
                            <span>Hướng dẫn</span>
                        </a>
                    </li>


                    <li class="<?php echo e((Request::is('*contact*') ? 'active' : '')); ?>">
                        <a href="<?php echo e(route('contact')); ?>" class="" title="Liên hệ">
                            <span>Liên hệ</span>
                        </a>
                    </li>


                </ul>

                <div class="visible-xs visible-sm closeMenuMB text-center">
                    <a href="javascript:void(0)" class="closeNav viewAll">Đóng</a>
                </div>
            </nav>
        </div>
    </div>
</nav>
