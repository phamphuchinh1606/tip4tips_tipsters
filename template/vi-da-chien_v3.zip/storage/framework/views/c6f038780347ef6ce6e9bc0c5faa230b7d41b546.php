<div class="block left-module product">
    <p class="title_block">Sản phẩm HOT</p>
    <div class="block_content">
        <!-- layered -->
        <div class="layered layered-category">
            <div class="layered-content">
                <div id="listPdHot">

                    <div class="itemProduct">

                        <div class="pdLoopItem animated zoomIn">
                            <div class="itemLoop clearfix">
                                <div class="pdLoopImg elementFixHeight">

                                    <div class="pdLabel sale">
                                        <span>- 14%</span>
                                    </div>


                                    <a href="/products/ao-khoac-cao-cap-px" title="Áo khoác cao cấp PX">
                                        <img alt="Áo khoác cao cấp PX" data-reg="true" class="imgLoopItem" src="<?php echo e(asset('./images/guest/product_detail/product_right_1.jpg')); ?>" style="width: auto;">
                                    </a>
                                    <div class="pdLoopAction hidden-sm hidden-xs">
                                        <div class="listAction">
                                            <a href="javascript:void(0)" class="add-cart btnLoop Addcart" data-variantid="1019673628" title="Thêm vào giỏ"><i class="fa fa-shopping-bag" aria-hidden="true"></i> <span>Thêm vào giỏ</span></a>
                                            <a href="javascript:void(0)" class="btnLoop btnQickview btn-quickview-1" data-handle="/products/ao-khoac-cao-cap-px" data-toggle="tooltip" data-placement="left" title="Xem nhanh"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pdLoopDetail text-center clearfix">
                                    <h3 class="pdLoopName"><a class="productName" href="/products/ao-khoac-cao-cap-px" title="Áo khoác cao cấp PX">Vi mua nhieu 01</a></h3>
                                    <p class="pdPrice">

                                        <span>1,900,000₫</span>
                                        <del class="pdComparePrice">2,200,000₫</del>

                                    </p>
                                    <div class="pdLoopListView">
                                        <ul class="notStyle">
                                            <li><strong>Mã sản phẩm: </strong><span>chưa rõ</span></li>
                                            <li><strong>Thương hiệu: </strong><span>Zalora</span></li>
                                            <li><strong>Mô tả ngắn: </strong>
                                                <span class="short-des">

							Thêm vào bộ sưu tập Thu Đông năm nay của bạn chiếc áo cardigan độc đáo đến từ thương hiệu ZALORA. Áo có chất liệu cotton mang lại cảm giác mềm mại, ấm áp khi mặc. Với màu sắc tối, kiểu dáng đơn giản nhưng được khéo léo phối da ở viền cổ áo và tay áo khiến bạn trông thật dịu dàng nhưng vẫn có cá tính riêng.- Chất liệu cotton- Cổ chữ V- Tay dài, gấu tay có phối da- Không có lót


						</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="itemProduct">










                        <div class="pdLoopItem animated zoomIn">
                            <div class="itemLoop clearfix">
                                <div class="pdLoopImg elementFixHeight">

                                    <div class="pdLabel sale">
                                        <span>- 9%</span>
                                    </div>


                                    <a href="/products/ao-khoac-hien-dai-kta" title="Áo khoác hiện đại KTA">
                                        <img alt="Áo khoác hiện đại KTA" data-reg="true" class="imgLoopItem" src="<?php echo e(asset('./images/guest/product_detail/product_right_2.jpg')); ?>" style="width: auto;">
                                    </a>
                                    <div class="pdLoopAction hidden-sm hidden-xs">
                                        <div class="listAction">
                                            <a href="javascript:void(0)" class="add-cart btnLoop Addcart" data-variantid="1019673629" title="Thêm vào giỏ"><i class="fa fa-shopping-bag" aria-hidden="true"></i> <span>Thêm vào giỏ</span></a>
                                            <a href="javascript:void(0)" class="btnLoop btnQickview btn-quickview-1" data-handle="/products/ao-khoac-hien-dai-kta" data-toggle="tooltip" data-placement="left" title="Xem nhanh"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pdLoopDetail text-center clearfix">
                                    <h3 class="pdLoopName"><a class="productName" href="/products/ao-khoac-hien-dai-kta" title="Áo khoác hiện đại KTA">Ví nổi bật 01</a></h3>
                                    <p class="pdPrice">

                                        <span>2,100,000₫</span>
                                        <del class="pdComparePrice">2,300,000₫</del>

                                    </p>
                                    <div class="pdLoopListView">
                                        <ul class="notStyle">
                                            <li><strong>Mã sản phẩm: </strong><span>chưa rõ</span></li>
                                            <li><strong>Thương hiệu: </strong><span>Zalora</span></li>
                                            <li><strong>Mô tả ngắn: </strong>
                                                <span class="short-des">

							Thêm vào bộ sưu tập Thu Đông năm nay của bạn chiếc áo cardigan độc đáo đến từ thương hiệu ZALORA. Áo có chất liệu cotton mang lại cảm giác mềm mại, ấm áp khi mặc. Với màu sắc tối, kiểu dáng đơn giản nhưng được khéo léo phối da ở viền cổ áo và tay áo khiến bạn trông thật dịu dàng nhưng vẫn có cá tính riêng.- Chất liệu cotton- Cổ chữ V- Tay dài, gấu tay có phối da- Không có lót


						</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="itemProduct">










                        <div class="pdLoopItem animated zoomIn">
                            <div class="itemLoop clearfix">
                                <div class="pdLoopImg elementFixHeight">

                                    <div class="pdLabel sale">
                                        <span>- 11%</span>
                                    </div>


                                    <a href="/products/ao-khoac-nu-xt-om" title="Áo khoác nữ XT-OM">
                                        <img alt="Áo khoác nữ XT-OM" data-reg="true" class="imgLoopItem" src="<?php echo e(asset('./images/guest/product_detail/product_right_3.jpg')); ?>" style="width: auto;">
                                    </a>
                                    <div class="pdLoopAction hidden-sm hidden-xs">
                                        <div class="listAction">
                                            <a href="javascript:void(0)" class="add-cart btnLoop Addcart" data-variantid="1019673608" title="Thêm vào giỏ"><i class="fa fa-shopping-bag" aria-hidden="true"></i> <span>Thêm vào giỏ</span></a>
                                            <a href="javascript:void(0)" class="btnLoop btnQickview btn-quickview-1" data-handle="/products/ao-khoac-nu-xt-om" data-toggle="tooltip" data-placement="left" title="Xem nhanh"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pdLoopDetail text-center clearfix">
                                    <h3 class="pdLoopName"><a class="productName" href="/products/ao-khoac-nu-xt-om" title="Áo khoác nữ XT-OM">Ví cao cấp 01</a></h3>
                                    <p class="pdPrice">

                                        <span>340,000₫</span>
                                        <del class="pdComparePrice">380,000₫</del>

                                    </p>
                                    <div class="pdLoopListView">
                                        <ul class="notStyle">
                                            <li><strong>Mã sản phẩm: </strong><span>chưa rõ</span></li>
                                            <li><strong>Thương hiệu: </strong><span>Zalora</span></li>
                                            <li><strong>Mô tả ngắn: </strong>
                                                <span class="short-des">

							Cho một mùa đông ấm áp nhưng không mất đi nét tinh tế, thời thượng cùng áo khoác có nón đến từ thương hiệu ZALORA. Áo được tạo từ chất liệu dày, xù thích hợp để giữ ấm cơ thể, kiểu dáng áo suông, rộng mang lại cảm giác thoải mái cho người mặc.- Chất liệu acrylic pha- Áo có nón- Tay dài- Dáng suông- Không có lót


						</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="itemProduct">










                        <div class="pdLoopItem animated zoomIn">
                            <div class="itemLoop clearfix">
                                <div class="pdLoopImg elementFixHeight">

                                    <div class="pdLabel sale">
                                        <span>- 10%</span>
                                    </div>


                                    <a href="/products/ao-khoac-tay-ngan-xt" title="Áo khoác tay ngắn XT">
                                        <img alt="Áo khoác tay ngắn XT" data-reg="true" class="imgLoopItem" src="<?php echo e(asset('./images/guest/product_detail/product_right_4.jpg')); ?>" style="width: auto;">
                                    </a>
                                    <div class="pdLoopAction hidden-sm hidden-xs">
                                        <div class="listAction">
                                            <a href="javascript:void(0)" class="add-cart btnLoop Addcart" data-variantid="1019673615" title="Thêm vào giỏ"><i class="fa fa-shopping-bag" aria-hidden="true"></i> <span>Thêm vào giỏ</span></a>
                                            <a href="javascript:void(0)" class="btnLoop btnQickview btn-quickview-1" data-handle="/products/ao-khoac-tay-ngan-xt" data-toggle="tooltip" data-placement="left" title="Xem nhanh"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pdLoopDetail text-center clearfix">
                                    <h3 class="pdLoopName"><a class="productName" href="/products/ao-khoac-tay-ngan-xt" title="Áo khoác tay ngắn XT">Ví mua nhiều nhất 04</a></h3>
                                    <p class="pdPrice">

                                        <span>450,000₫</span>
                                        <del class="pdComparePrice">500,000₫</del>

                                    </p>
                                    <div class="pdLoopListView">
                                        <ul class="notStyle">
                                            <li><strong>Mã sản phẩm: </strong><span>chưa rõ</span></li>
                                            <li><strong>Thương hiệu: </strong><span>Zalora</span></li>
                                            <li><strong>Mô tả ngắn: </strong>
                                                <span class="short-des">

							Cho một mùa đông ấm áp nhưng không mất đi nét tinh tế, thời thượng cùng áo khoác có nón đến từ thương hiệu ZALORA. Áo được tạo từ chất liệu dày, xù thích hợp để giữ ấm cơ thể, kiểu dáng áo suông, rộng mang lại cảm giác thoải mái cho người mặc.- Chất liệu acrylic pha- Áo có nón- Tay dài- Dáng suông- Không có lót


						                        </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>