<?php

namespace App\Logics;

use App\Common\Constant;
use App\Models\Product;

class ProductLogic extends BaseLogic{

    public function createProduct($params = []){
        if(count($params) > 0){
            $product = new Product();
            $product->product_name = $params['product_name'];
            $product->product_code = $params['product_code'];
            $product->vendor_id = $params['vendorId'];
            $product->product_type_id = $params['productTypeId'];
            $product->product_price = $params['productPrice'];
            $product->product_compare_price = $params['productComparePrice'];
            $product->product_sale_percent = $params['productSale_Percent'];
            $product->is_public = 1;


        }
    }
}
