<?php

namespace App\Services;

use App\Common\AppCommon;
use Illuminate\Http\Request;

class ProductService extends BaseService{
    public function createProduct(Request $request){
        $params = [];
        $params['productName'] = $request->product_name;
        $params['productCode'] = $request->product_code;
        $params['vendorId'] = $request->vendor;
        $params['productType'] = $request->product_type;
        $params['productPrice'] = $request->product_price;
        $params['productCostPrice'] = $request->product_cost_price;
        $params['productComparePrice'] = $request->product_compare_price;
        $params['productSalePercent'] = $request->product_sale_percent;
        $params['isPublic'] = $request->is_public;
        $params['productDescription'] = $request->product_description;
        $params['productContent'] = $request->product_content;
        $productImage = $request->file('product_images') ;
        if(isset($productImage)){
            $params['productImage'] = $productImage;
        }
        $productImages = $request->product_images;
        if(isset($productImages)){

        }

    }
}
