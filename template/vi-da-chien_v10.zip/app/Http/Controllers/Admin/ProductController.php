<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Storage;

class ProductController extends Controller
{
    public function index(){
        return view('admin.product.index');
    }

    public function showCreate(){
        return view('admin.product.create');
    }

    public function store(Request $request){
        $data = $request->image_test;
        dd($request);


    }


}
