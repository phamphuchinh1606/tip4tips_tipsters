<section id="banner-home-top" class="">
    <div class="container">
        <div class="block-group-banner">


            <div class="col-xs-12 col-sm-4 padding-0 item banner-boder-zoom2 first">
                <a href="#" class="">
                    <img src="<?php echo e(asset('./images/guest/banner_top/banner_top_1.jpg')); ?>"
                         alt="alt"/>
                </a>
            </div>


            <div class="col-xs-12 col-sm-4 padding-0 item banner-boder-zoom2">
                <a href="#" class="">
                    <img src="<?php echo e(asset('./images/guest/banner_top/banner_top_2.jpeg')); ?>"
                         alt="alt"/>
                </a>
            </div>


            <div class="col-xs-12 col-sm-4 padding-0 item banner-boder-zoom2 last">
                <a href="#" class="">
                    <img src="<?php echo e(asset('./images/guest/banner_top/banner_top_3.jpg')); ?>"
                         alt="alt"/>
                </a>
            </div>


        </div>
    </div>
</section>