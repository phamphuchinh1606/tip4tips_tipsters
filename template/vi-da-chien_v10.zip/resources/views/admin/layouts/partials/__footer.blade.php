<footer class="app-footer">
    <div>
        <a href="https://coreui.io/pro/">CoreUI Pro</a>
        <span>© 2018 creativeLabs.</span>
    </div>
    <div class="ml-auto">
        <span>Powered by</span>
        <a href="https://coreui.io/pro/">CoreUI Pro</a>
    </div>
</footer>
