<div class="banner-slider">
    <div class="blogsList">
        <ul class="bannerSlider owlDesign notDots notStyle">


            <li class="articleItem">
                <a href="/collections/thoi-trang-nu">
                    <img src="<?php echo e(asset('./images/guest/banner/bn4.png')); ?>" alt="slider"></a>
            </li>


            <li class="articleItem">
                <a href="/collections/thoi-trang-nu">
                    <img src="<?php echo e(asset('./images/guest/banner/bn2.jpg')); ?>" lt="slider"></a>
            </li>


            <li class="articleItem">
                <a href="/collections/ac-khoac-nu">
                    <img src="<?php echo e(asset('./images/guest/banner/bn3.jpg')); ?>" alt="slider"></a>
            </li>


        </ul>

    </div>
</div>