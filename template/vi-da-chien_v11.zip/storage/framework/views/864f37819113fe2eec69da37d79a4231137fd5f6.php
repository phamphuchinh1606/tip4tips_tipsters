<?php $__env->startSection('head.title','Ví Da Khắc Tên'); ?>

<?php $__env->startSection('template','cart'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href='<?php echo e(asset('/css/guest/plugins/pages.css?v=1543')); ?>' rel='stylesheet' type='text/css'  media='all'  />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <section id="insCartPage" class="bg_w ajax-cart-popup">
        <div class="container">
            <div class="content">
                <div id="AjaxifyCart" class="ajaxcart">
                    <h1 class="page-header">Giỏ Hàng</h1>

                    <div class="page-content">
                        <div class="row">
                            <div class="boxCart leftCart col-md-8 col-sm-12 col-xs-12 ">
                                <div class="cart_header_labels hidden-xs clearfix">
                                    <div class="label_item col-xs-12 col-sm-2 col-md-2">
                                        <div class="cart_product first_item">
                                            Sản phẩm
                                        </div>
                                    </div>
                                    <div class="label_item col-xs-12 col-sm-3 col-md-3">
                                        <div class="cart_description item">
                                            Mô Tả
                                        </div>
                                    </div>
                                    <div class="label_item col-xs-12 col-sm-2 col-md-2">
                                        <div class="cart_price item">
                                            Giá
                                        </div>
                                    </div>
                                    <div class="label_item col-xs-12 col-sm-2 col-md-2">
                                        <div class="cart_quantity item">
                                            Số Lượng
                                        </div>
                                    </div>
                                    <div class="label_item col-xs-12 col-sm-2 col-md-2">
                                        <div class="cart_total item">
                                            Tổng
                                        </div>
                                    </div>
                                    <div class="label_item col-xs-12 col-sm-1 col-md-1">
                                        <div class="cart_delete last_item">
                                            Xóa
                                        </div>
                                    </div>
                                </div>
                                <div class="ajax_content_cart">

                                    <div class="list_product_cart clearfix" data-id="1019623662">
                                        <div class="cpro_item image col-xs-3 col-sm-2 col-md-2">




                                            <div class="cpro_item_inner">
                                                <a href="<?php echo e(route('product_detail')); ?>" class="cart__image">
                                                    <img class="img-responsive" src="<?php echo e(asset('images/guest/product/vinam/product_1.jpg')); ?>" alt="Áo sơ mi dài tay Aristino ALS021">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="cpro_item text-left title col-xs-9 col-sm-3 col-md-3">
                                            <div class="cpro_item_inner">
                                                <a href="<?php echo e(route('product_detail')); ?>" class="product_name">
                                                    Ví khắc tên cao cấp
                                                </a>

                                                <small>Trắng / M</small>

                                            </div>
                                        </div>
                                        <div class="cpro_item price col-xs-9 col-sm-2 col-md-2">
                                            <div class="cpro_item_inner">
                                                <span class="price product-price"><span class="money">339,000₫</span></span>
                                            </div>
                                        </div>
                                        <div class="cpro_item qty text-center col-xs-6 col-sm-2 col-md-2">
                                            <div class="cpro_item_inner">
                                                <div class="ajaxcart__qty">
                                                    <input type="number" class="ajaxcart__qty-num" min="1" value="2" data-id="1019623662" aria-label="quantity" pattern="[0-9]*">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cpro_item line-price col-xs-12 col-sm-2 col-md-2 hidden-xs">
                                            <div class="cpro_item_inner">
                                                <span class="price product-price money_line"><span class="money">678,000₫</span></span>
                                                <input type="hidden" value="678,000₫" data-id="1019623662" class="line_money_temp">
                                            </div>
                                        </div>
                                        <div class="cpro_item remove col-xs-2 col-sm-1 col-md-1">
                                            <div class="cpro_item_inner">
                                                <a href="/cart/change?line=1&amp;quantity=0" class="cart__remove ajaxcart__remove" data-id="1019623662">
                                                    <i class="fa fa-trash-o" aria-hidden="true"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="boxCart rightCart col-md-4 col-sm-12 col-xs-12 ">
                                <div class="list_button_cart clearfix">
                                    <div class="actionCart clearfix text-right">
                                        <p>
                                            <span class="cart__subtotal-title pull-left">Tổng</span>
                                            <span class="h3 cart__subtotal pull-right"><span class="money">678,000₫</span></span>
                                        </p>
                                        <!--<p><em>Đã bao gồm thuế và phí Shipping</em></p>-->
                                        <div class="groupButton text-center">
                                            <a class="btn con-ajax-cart btn-outline insButton" href="<?php echo e(route('collection')); ?>" title="Tiếp Tục Mua Sắm">Tiếp Tục Mua Sắm</a>
                                            <input type="submit" onclick="window.location = &quot;/checkout&quot;" name="checkout" class="btn btn-outline checkout insButton" value="Thanh Toán">
                                        </div>
                                    </div>
                                    <div class="note_item">

                                        <div class="note_cart">
                                            <label class="control-label" for="CartSpecialInstructions">Chú Thích</label>
                                            <textarea name="note" class="form-control" placeholder="Bạn muốn mô tả rõ hơn về đơn hàng..." id="CartSpecialInstructions"></textarea>
                                        </div>

                                    </div>


                                    <div class="pd_saler">
                                        <h3>Dịch vụ &amp; Khuyến mãi</h3>

                                        <p>
                                            Nhập mã ECQLJKY7QROS khi thanh toán, giảm ngay 50.000đ.
                                        </p>


                                        <p>
                                            Tặng mã coupon giảm 500.000đ khi đơn hàng trên 10 triệu đồng.
                                        </p>


                                        <p>
                                            Giao hàng miễn phí trong nội thành Tp. Hồ Chí Minh
                                        </p>


                                        <p>
                                            Giảm ngay 20% đối với những sản phẩm thuộc nhóm Oppo
                                        </p>


                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>