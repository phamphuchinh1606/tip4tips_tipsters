<?php

namespace App\Services;

use App\Common\AppCommon;
use App\Common\Constant;
use Illuminate\Http\Request;
use Storage;

class ProductService extends BaseService{

    public function getAllLProduct(){
        return $this->productLogic->getAllLProduct();
    }

    public function createProduct(Request $request){
        $params = [];
        $params['productName'] = $request->product_name;
        $params['productCode'] = $request->product_code;
        $params['vendorId'] = $request->vendor;
        $params['productTypeId'] = $request->product_type;
        $params['productPrice'] = $request->product_price;
        $params['productCostPrice'] = $request->product_cost_price;
        $params['productComparePrice'] = $request->product_compare_price;
        $params['productSalePercent'] = $request->product_sale_percent;
        $params['isPublic'] = AppCommon::getIsPublic($request->is_public);
        $params['productDescription'] = $request->product_description;
        $params['productContent'] = $request->product_content;
        $product = $this->productLogic->createProduct($params);
        if($product != null){
            $productId = $product->id;
            $productImage = $request->file('product_main_image') ;
            $imageName = AppCommon::moveImageProduct($productImage, $productId);
            $product = $this->productLogic->updateImage($product,$imageName);
            $productImages = $request->product_images;
            if(isset($productImages) && count($productImages)){
               foreach ($productImages as $image){
                   $moveImageName = str_replace(Constant::$PATH_FOLDER_UPLOAD_IMAGE_DROP,Constant::$PATH_FOLDER_UPLOAD_PRODUCT.'/'.$productId, $image);
                   Storage::move($image, $moveImageName);
                   $this->productImageLogic->create($productId,$moveImageName);
               }
            }
        }
        return $product;
    }
}
