<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Storage;

class ProductController extends Controller
{
    public function index(){
        $products = $this->productService->getAllLProduct();
        dd($products);
        return view('admin.product.index',[
            'products' => $products
        ]);
    }

    public function showCreate(){
        return view('admin.product.create');
    }

    public function store(Request $request){
        $this->productService->createProduct($request);

    }


}
