<?php

namespace App\Logics;

use App\Models\ProductImage;

class ProductImageLogic extends BaseLogic{

    public function create($productId, $srcImage){
        $productImage = new ProductImage();
        $productImage->product_id = $productId;
        $productImage->image_src = $srcImage;
        $productImage->save();
        return $productImage;
    }
}
