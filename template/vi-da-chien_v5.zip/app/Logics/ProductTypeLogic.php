<?php

namespace App\Logics;

use App\Common\Constant;
use App\Models\ProductType;

class ProductTypeLogic extends BaseLogic{
    public function getAll(){
        return ProductType::where('is_delete',Constant::$DELETE_FLG_OFF)->get();
    }

    public function create($productTypeName, $isPublic){
        $productType = new ProductType();
        $productType->product_type_name = $productTypeName;
        $productType->is_public = $isPublic;
        return $productType->save();
    }

    public function findId($productTypeId){
        return ProductType::find($productTypeId);
    }
}