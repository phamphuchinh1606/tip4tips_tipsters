<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(){
        return view('admin.product.index');
    }

    public function showCreate(){
        return view('admin.product.create');
    }
}
