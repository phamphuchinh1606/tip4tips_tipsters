<?php

namespace App\Http\Controllers\Admin;

use App\Common\Constant;
use Illuminate\Http\Request;

class ProductTypeController extends Controller
{
    public function index(){
        $listProductType = $this->productTypeService->getAll();
        return $this->viewAdmin('productType.index',[
            'listProductType' => $listProductType
        ]);
    }

    public function showCreate(){
        return $this->viewAdmin('productType.create');
    }

    public function store(Request $request){
        $productTypeName = $request->product_type_name;
        $isPublic = Constant::$PUBLIC_FLG_ON;
        if($request->is_public == "Off" || $request->is_public == null){
            $isPublic = Constant::$PUBLIC_FLG_OFF;
        }
        $productType = $this->productTypeService->create($productTypeName,$isPublic);
        if(isset($productType->id)){
            return redirect()->route('admin.product_type.update',['id' => $productType->id]);
        }
        return redirect()->route('admin.product_type.index');
    }

    public function showUpdate($id){
        $productType = $this->productTypeService->findId($id);
        if($productType->is_public == Constant::$PUBLIC_FLG_ON){
            $productType->is_check_public = 'checked';
        }
        return $this->viewAdmin('productType.update',['productType' => $productType]);
    }
}
