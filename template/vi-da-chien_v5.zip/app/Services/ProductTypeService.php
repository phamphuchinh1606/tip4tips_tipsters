<?php

namespace App\Services;

use App\Common\AppCommon;

class ProductTypeService extends BaseService{

    public function create($productTypeName, $isPublic){
        return $this->productTypeLogic->create($productTypeName, $isPublic);
    }

    public function findId($productTypeId){
        return $this->productTypeLogic->findId($productTypeId);
    }

    public function getAll(){
        $listProductType = $this->productTypeLogic->getAll();
        foreach ($listProductType as $productType){
            $productType->public_name = AppCommon::namePublicProductType($productType->is_public);
            $productType->public_class = AppCommon::classPublicProductType($productType->is_public);
        }
        return $listProductType;
    }
}