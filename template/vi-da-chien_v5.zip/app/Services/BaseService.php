<?php

namespace App\Services;

use App\Logics\ProductTypeLogic;

class BaseService {
    protected $productTypeLogic;

    public function __construct(ProductTypeLogic $productTypeLogic)
    {
        $this->productTypeLogic = $productTypeLogic;
    }
}