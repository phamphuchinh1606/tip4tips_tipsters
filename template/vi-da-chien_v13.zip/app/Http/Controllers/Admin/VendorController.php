<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class VendorController extends Controller
{
    public function index(){
        return $this->viewAdmin('vendor.index');
    }
}
