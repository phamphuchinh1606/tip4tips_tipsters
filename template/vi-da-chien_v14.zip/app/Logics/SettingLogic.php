<?php

namespace App\Logics;

use App\Common\Constant;
use App\Models\SettingBanner;

class SettingLogic extends BaseLogic{
    public function getBannerAll(){
        return SettingBanner::all();
    }

    public function createBanner($srcImage){
        $banner = new SettingBanner();
        $banner->src_image = $srcImage;
        $banner->save();
        return $banner;
    }

    public function deleteBanner($bannerId){
        SettingBanner::destroy($bannerId);
    }
}
