<?php

namespace App\Services;

use App\Logics\ProductTypeLogic;
use App\Logics\ProductLogic;
use App\Logics\ProductImageLogic;
use App\Logics\VendorLogic;
use App\Logics\SettingLogic;

class BaseService {
    protected $productTypeLogic;

    protected $productLogic;

    protected $productImageLogic;

    protected $vendorLogic;

    protected $settingLogic;

    public function __construct(ProductTypeLogic $productTypeLogic, ProductLogic $productLogic,
                                ProductImageLogic $productImageLogic , VendorLogic $vendorLogic,
                                SettingLogic $settingLogic)
    {
        $this->productTypeLogic = $productTypeLogic;
        $this->productLogic = $productLogic;
        $this->productImageLogic = $productImageLogic;
        $this->vendorLogic = $vendorLogic;
        $this->settingLogic = $settingLogic;
    }
}
