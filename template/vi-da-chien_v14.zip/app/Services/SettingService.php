<?php

namespace App\Services;

use App\Common\AppCommon;
use App\Common\Constant;
use Illuminate\Http\Request;

class SettingService extends BaseService{

    public function getBannerAll(){
        return $this->settingLogic->getBannerAll();
    }

    public function createBanner(Request $request){
        $fileImage = $request->file('src_image');
        if(isset($fileImage)){
            $srcImage = AppCommon::moveImage($fileImage, Constant::$PATH_FOLDER_UPLOAD_IMAGE_BANNER);
            return $this->settingLogic->createBanner($srcImage);
        }
        return null;
    }

    public function deleteBanner($bannerId){
        $this->settingLogic->deleteBanner($bannerId);
    }
}
