<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function bannerList(){
        $banners = $this->settingService->getBannerAll();
        return $this->viewAdmin('setting.banner_slider',[
            'banners' => $banners
        ]);
    }

    public function bannerCreate(Request $request){
        $this->settingService->createBanner($request);
        return redirect()->route('admin.setting.banner');
    }

    public function bannerDestroy($id){
        $this->settingService->deleteBanner($id);
        return redirect()->route('admin.setting.banner');
    }
}
