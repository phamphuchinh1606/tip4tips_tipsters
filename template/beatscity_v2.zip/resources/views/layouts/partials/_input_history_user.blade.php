<input type="hidden" name="affected_object" value="{{ isset($affectedValue) ? $affectedValue : '' }}">
<input type="hidden" name="action_history" value="{{ isset($actionValue) ? $actionValue : '' }}">
<input type="hidden" name="description_history" value="{{ isset($descriptionValue) ? $descriptionValue : '' }}">
<input type="hidden" name="name_update" value="{{ isset($nameUpdateValue) ? $nameUpdateValue : '' }}">
<input type="hidden" name="name_object_history" value="{{ isset($nameObjectValue) ? $nameObjectValue : '' }}">
<input type="hidden" name="id_update" value="{{ isset($idUpdateValue) ? $idUpdateValue : '' }}">