<?php
namespace App\Common;

class Utils{

    //path image
    public static $PATH__IMAGE = "images/upload";
    //path default image
    public static $PATH__DEFAULT__IMAGE = "images/no_image_available.jpg";
    //path default avatar
    public static $PATH__DEFAULT__AVATAR = "images/no_image_available.jpg";

    public static $API_NAME_TWITTER = 'twitter';
    public static $API_NAME_FACEBOOK = 'facebook';
    public static $API_NAME_INSTAGRAM = 'instagram';

    public static function pathUploadImage($foderName){
        $pathUploadImage = config('app.path_upload_image');
        if(!isset($pathUploadImage)){
            $pathUploadImage = public_path();
        }
        return $pathUploadImage.'/'.$foderName;
    }

}
