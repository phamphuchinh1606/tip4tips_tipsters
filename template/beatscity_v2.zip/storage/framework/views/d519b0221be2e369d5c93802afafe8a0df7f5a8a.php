<?php $__env->startSection('title', 'Edit Action'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            <a href="<?php echo e(route('action.index')); ?>" class="btn btn-xs btn-default pull-right"><i class="fa fa-angle-left"></i> Back to list</a>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6 col-sm-push-3">
                    <form role="form" method="post" action="<?php echo e(route('action.edit',['id' => $action->id])); ?>" enctype = "multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php if(count($errors) > 0): ?>
                                    <strong>Whoops!</strong> There were some problems with your input.
                                <?php endif; ?>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div><br />
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label>Action Name</label>
                            <input name="name" value="<?php echo e($action->name); ?>" type="text" class="form-control" placeholder="Enter ..." required>
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label>Description</label>
                            <textarea name="description" class="form-control" placeholder="Enter..." rows="5"><?php echo e($action->description); ?></textarea>
                        </div>

                        <div class="form-action">
                            <a href="<?php echo e(route('action.index')); ?>" class="btn btn-default">Cancel</a>
                            <button type="submit" class="btn btn-primary pull-right">Update</button>
                        </div>
                        <!-- /.box-body -->
                    </form>
                </div>
            </div>
        </div>
        <!-- /.col -->

    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>