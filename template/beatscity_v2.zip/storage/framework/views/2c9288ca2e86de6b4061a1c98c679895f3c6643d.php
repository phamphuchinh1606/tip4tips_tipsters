<?php use App\Common\Utils; ?>

<?php $__env->startSection('title', 'Create Venue'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/intlTelInput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/intlTelInput.js')); ?>"></script>
    <script>
        $("#phone").intlTelInput({
            allowDropdown: false,
            localizedCountries: {'de': 'Deutschland' },
            preferredCountries: ['vn', 'jp'],
            separateDialCode: true,
            utilsScript: "<?php echo e(asset('js/admin/utils.js')); ?>"
        });
        // $("#phone").on("countrychange", function(e, countryData) {
        //     console.log(e);
        //     console.log(countryData.dialCode);
        //     // $('#phone').val();
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <form role="form" method="post" action="<?php echo e(route('venue.create')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-md-8">
                    <!-- create manager form -->
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                            <a href="<?php echo e(route('venue.index')); ?>" class="btn btn-xs btn-default pull-right"><i class="fa fa-angle-left"></i> Back to list</a>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e(\Session::get('success')); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-xs-6">
                                    <!-- text input -->
                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                        <label>Full name</label>
                                        <input name="name" value="<?php echo e(old('name')); ?>" type="text" class="form-control" placeholder="Enter ..." required>
                                        <?php if($errors->has('name')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-xs-6">
                                    <!-- text input -->
                                    <div class="form-group<?php echo e($errors->has('venue_type') ? ' has-error' : ''); ?>">
                                        <label>Venue Type</label>
                                        <select name="venue_type" class="form-control" required>
                                            <option value="" disabled selected>Please pick a venue type</option>
                                            <?php $__currentLoopData = $venueTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venueType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($venueType->id); ?>" <?php if(old('venue_type') == $venueType->id): ?> selected <?php endif; ?>><?php echo e($venueType->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('venue_type')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('venue_type')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                    <!-- text input -->
                                    <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                                        <label>City</label>
                                        <select name="city" class="form-control" required>
                                            <option value="" disabled selected>Please pick a city</option>
                                            
                                            
                                            
                                            <option value="Hồ Chí Minh">Hồ Chí Minh</option>
                                            <option value="Hà Nội">Hà Nội</option>
                                            <option value="Đà Nẵng">Đà Nẵng</option>
                                            <option value="Cần Thơ">Cần Thơ</option>
                                        </select>
                                        <?php if($errors->has('region')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('region')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-xs-6">
                                    <!-- text input -->
                                    <div class="form-group<?php echo e($errors->has('ward') ? ' has-error' : ''); ?>">
                                        <label>Ward</label>
                                        <select name="ward" class="form-control" required>
                                            <option value="" disabled selected>Please pick a ward</option>
                                            
                                            
                                            
                                            <option value="Quận 1">Quận 1</option>
                                            <option value="Quận 2">Quận 2</option>
                                            <option value="Quận 3">Quận 3</option>
                                            <option value="Quận 4">Quận 4</option>
                                        </select>
                                        <?php if($errors->has('ward')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('ward')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                    <!-- text input -->
                                    <div class="form-group<?php echo e($errors->has('district') ? ' has-error' : ''); ?>">
                                        <label>District</label>
                                        <select name="district" class="form-control" required>
                                            <option value="" disabled selected>Please pick a city</option>
                                            
                                            
                                            
                                            <option value="Phường 1">Phường 1</option>
                                            <option value="Phường 2">Phường 2</option>
                                            <option value="Phường 3">Phường 3</option>
                                            <option value="Phường 4">Phường 4</option>
                                        </select>
                                        <?php if($errors->has('district')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('district')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-xs-6">
                                    <!-- text input -->
                                    <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                                        <label>Address</label>
                                        <input name="address" value="<?php echo e(old('address')); ?>" type="text" class="form-control" placeholder="Enter ..." required>
                                        <?php if($errors->has('address')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('address')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                                
                                    
                                        
                                        
                                               
                                    
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                            
                                
                                    
                                        
                                        
                                            
                                            
                                                
                                            
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                            
                                            
                                                
                                            
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <input id="imgHandleInput" name="image" type="file" value="">
                            <a href="<?php echo e(route('venue.index')); ?>" class="btn btn-default">Cancel</a>
                            <button type="submit" class="btn btn-primary pull-right">Create</button>
                        </div>
                    </div>

                    <!-- /.box -->
                </div>
                <div class="col-md-4">
                    <!-- Profile Image -->
                    <div class="box box-warning">
                        <div class="box-body box-profile">
                            <div class="upload__area-image">
                        <span>
                            <img id="imgHandle" src="<?php echo e(asset(Utils::$PATH__IMAGE)); ?>/no_image_available.jpg">
                            <label for="imgAnchorInput">Upload image</label>
                        </span>
                                <p><small>(Please upload a file of type: jpeg, png, jpg, gif, svg.)</small></p>
                            </div>
                            <div class="form__upload">
                                <form action="" enctype="multipart/form-data" method="post">
                                    <div class="form-inline-simple">
                                        <input type="file" class="'form-control" id="imgAnchorInput" onchange="loadFile(event)">
                                        
                                        
                                    </div>
                                    <script>
                                        var loadFile = function(event) {
                                            var output = document.getElementById('imgHandle');
                                            output.src = URL.createObjectURL(event.target.files[0]);
                                            document.getElementById('imgHandleInput').files = event.target.files;
                                        };
                                    </script>

                                </form>

                            </div>
                        </div>
                    </div>
                    <!-- /.box -->
                </div>

            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>